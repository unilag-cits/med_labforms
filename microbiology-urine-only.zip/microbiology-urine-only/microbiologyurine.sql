-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2021 at 03:14 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `haematology`
--

-- --------------------------------------------------------

--
-- Table structure for table `microbiologyurine`
--

CREATE TABLE `microbiologyurine` (
  `id` int(11) NOT NULL,
  `PatientID` int(9) NOT NULL,
  `viewID` int(11) NOT NULL,
  `clinician` varchar(250) NOT NULL,
  `diagnosis` varchar(250) NOT NULL,
  `material` varchar(250) NOT NULL,
  `ward` varchar(250) NOT NULL,
  `docsign` varchar(250) NOT NULL,
  `requestdate` date NOT NULL,
  `puscells` varchar(50) NOT NULL,
  `rbcs` varchar(50) NOT NULL,
  `epithcell` varchar(50) NOT NULL,
  `bacteriaa` varchar(50) NOT NULL,
  `yeast` varchar(50) NOT NULL,
  `casts` varchar(50) NOT NULL,
  `amorphous` varchar(50) NOT NULL,
  `crystals` varchar(50) NOT NULL,
  `spermatozoa` varchar(50) NOT NULL,
  `puscount` varchar(50) NOT NULL,
  `pusml` varchar(50) NOT NULL,
  `ziehlstain` varchar(50) NOT NULL,
  `AUG1` varchar(250) NOT NULL,
  `AUG2` varchar(250) NOT NULL,
  `AUG3` varchar(250) NOT NULL,
  `AMX1` varchar(250) NOT NULL,
  `AMX2` varchar(250) NOT NULL,
  `AMX3` varchar(250) NOT NULL,
  `PEN1` varchar(250) NOT NULL,
  `PEN2` varchar(250) NOT NULL,
  `PEN3` varchar(250) NOT NULL,
  `STREP1` varchar(250) NOT NULL,
  `STREP2` varchar(250) NOT NULL,
  `STREP3` varchar(250) NOT NULL,
  `COT1` varchar(250) NOT NULL,
  `COT2` varchar(250) NOT NULL,
  `COT3` varchar(250) NOT NULL,
  `N'FUR1` varchar(250) NOT NULL,
  `N'FUR2` varchar(250) NOT NULL,
  `N'FUR3` varchar(250) NOT NULL,
  `CXC1` varchar(250) NOT NULL,
  `CXC2` varchar(250) NOT NULL,
  `CXC3` varchar(250) NOT NULL,
  `ERY1` varchar(250) NOT NULL,
  `ERY2` varchar(250) NOT NULL,
  `ERY3` varchar(250) NOT NULL,
  `CHLO1` varchar(250) NOT NULL,
  `CHLO2` varchar(250) NOT NULL,
  `CHLO3` varchar(250) NOT NULL,
  `TET1` varchar(250) NOT NULL,
  `TET2` varchar(250) NOT NULL,
  `TET3` varchar(250) NOT NULL,
  `SXT1` varchar(250) NOT NULL,
  `SXT2` varchar(250) NOT NULL,
  `SXT3` varchar(250) NOT NULL,
  `GM1` varchar(250) NOT NULL,
  `GM2` varchar(250) NOT NULL,
  `GM3` varchar(250) NOT NULL,
  `OFL1` varchar(250) NOT NULL,
  `OFL2` varchar(250) NOT NULL,
  `OFL3` varchar(250) NOT NULL,
  `CAZ1` varchar(250) NOT NULL,
  `CAZ2` varchar(250) NOT NULL,
  `CAZ3` varchar(250) NOT NULL,
  `NA1` varchar(250) NOT NULL,
  `NA2` varchar(250) NOT NULL,
  `NA3` varchar(250) NOT NULL,
  `CRX1` varchar(250) NOT NULL,
  `CRX2` varchar(250) NOT NULL,
  `CRX3` varchar(250) NOT NULL,
  `CPR1` varchar(250) NOT NULL,
  `CPR2` varchar(250) NOT NULL,
  `CPR3` varchar(250) NOT NULL,
  `CXM1` varchar(250) NOT NULL,
  `CXM2` varchar(250) NOT NULL,
  `CXM3` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `microbiologyurine`
--
ALTER TABLE `microbiologyurine`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `microbiologyurine`
--
ALTER TABLE `microbiologyurine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
