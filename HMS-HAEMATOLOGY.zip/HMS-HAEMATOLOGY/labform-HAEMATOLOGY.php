<?php
session_start();
error_reporting(0);
include 'include/config.php';
include 'include/checklogin.php';
check_login();
if (isset($_POST['pt'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $marijana = $_POST['marijana'];
  $cocaine = $_POST['cocaine'];
  $benzo = $_POST['benzo'];
  $tricy = $_POST['tricy'];
  $metha = $_POST['metha'];
  $opium = $_POST['opium'];
  $amphe = $_POST['amphe'];
  $metyl = $_POST['metyl'];
  $barbi = $_POST['barbi'];
  $trama = $_POST['trama'];
  $others = $_POST['other'];
  $comment = $_POST['comment'];
  $conclusion = $_POST['conclusion'];
  $doctorsign = $_POST['docsign'];
  $labsign = $_POST['medlab'];
  $request = $_POST['requestdate'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO toxicology (PatientID, viewID, clinician, diagnosis, material, marijana, cocaine, benzodiazephine, tricyclic_antidepressants, methadone, opium, amphetamine, metylene_dioxymethamphe, barbiturates, tramadol, others, comment, conclusion, doctorsign, labsign, requestDate, resultDate)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material', '$marijana', '$cocaine', '$benzo', '$tricy', '$metha', '$opium', '$amphe', '$metyl', '$barbi', '$trama', '$others', '$comment', '$conclusion', '$docid', '$labsign', '$request', '$labdate')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['radiology'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $marijana = $_POST['marijana'];
  $cocaine = $_POST['cocaine'];
  $benzo = $_POST['benzo'];
  $tricy = $_POST['tricy'];
  $metha = $_POST['metha'];
  $opium = $_POST['opium'];
  $amphe = $_POST['amphe'];
  $metyl = $_POST['metyl'];
  $barbi = $_POST['barbi'];
  $trama = $_POST['trama'];
  $others = $_POST['other'];
  $comment = $_POST['comment'];
  $conclusion = $_POST['conclusion'];
  $doctorsign = $_POST['docsign'];
  $labsign = $_POST['medlab'];
  $request = $_POST['requestdate'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO toxicology (PatientID, viewID, clinician, diagnosis, material, marijana, cocaine, benzodiazephine, tricyclic_antidepressants, methadone, opium, amphetamine, metylene_dioxymethamphe, barbiturates, tramadol, others, comment, conclusion, doctorsign, labsign, requestDate, resultDate)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material', '$marijana', '$cocaine', '$benzo', '$tricy', '$metha', '$opium', '$amphe', '$metyl', '$barbi', '$trama', '$others', '$comment', '$conclusion', '$docid', '$labsign', '$request', '$labdate')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['haematology'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $ward = $_POST['ward'];
  $requestdate = $_POST['requestdate'];
  $docsign = $_POST['docsign'];
  $fullbloodc = $_POST['fullbloodc'];
  $haemaPVC = $_POST['haemaPVC'];
  $haemoglobin = $_POST['haemoglobin'];
  $RBC = $_POST['RBC'];
  $WBC = $_POST['WBC'];
  $polys = $_POST['polys'];
  $lymp = $_POST['lymp'];
  $monos = $_POST['monos'];
  $eosin = $_POST['eosin'];
  $baso = $_POST['baso'];
  $baso1 = $_POST['baso1'];
  $mvc = $_POST['mvc'];
  $mch = $_POST['mch'];
  $mchc = $_POST['mchc'];
  $boxESR = $_POST['boxESR'];
  $ESR = $_POST['ESR'];
  $boxRC = $_POST['boxRC'];
  $RC = $_POST['RC'];
  $boxhbgene = $_POST['boxhbgene'];
  $sicklingtest = $_POST['sicklingtest'];
  $boxBG = $_POST['boxBG'];
  $boxmalaria = $_POST['boxmalaria'];
  $boxhepatitisB	 = $_POST['boxhepatitisB'];
  $hepatitisB = $_POST['hepatitisB'];
  $boxhepatitisC = $_POST['boxhepatitisC'];
  $hepatitisC = $_POST['hepatitisC'];
  $boxHIV = $_POST['boxHIV'];
  $HIV = $_POST['HIV'];
  $boxVDRL = $_POST['boxVDRL'];
  $VDRL = $_POST['VDRL'];
  $boxHpylori = $_POST['boxHpylori'];
  $BG   = $_POST['BG'];
  $malaria   = $_POST['malaria'];
  $Hpylori   = $_POST['Hpylori'];
  $StyphiO  = $_POST['StyphiO'];
  $StyphiH   = $_POST['StyphiH'];
  $StyphiVI  = $_POST['StyphiVI'];
  $StparatyphiAO = $_POST['StparatyphiAO'];
  $StparatyphiAH = $_POST['StparatyphiAH'];
  $StparatyphiAVI = $_POST['StparatyphiAVI'];
  $StparatyphiBO = $_POST['StparatyphiBO'];
  $StparatyphiBH = $_POST['StparatyphiBH'];
  $StparatyphiBVI = $_POST['StparatyphiBVI'];
  $SparatyphiCO = $_POST['SparatyphiCO'];
  $SparatyphiCH = $_POST['SparatyphiCH'];
  $SparatyphiCVI = $_POST['SparatyphiCVI'];

  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO haematology (PatientID, viewID, clinician, diagnosis, material, ward, requestdate, docsign, fullbloodc, haemaPVC, haemoglobin, RBC, WBC, polys, lymp, monos, eosin, baso, baso1, mvc, mch, mchc, boxESR, ESR, boxRC, RC, boxhbgene, hbgene, boxsicklingtest, sicklingtest, boxBG, boxmalaria, boxhepatitisB, hepatitisB, boxhepatitisC, hepatitisC, boxHIV, HIV, boxVDRL, VDRL, boxHpylori, BG, malaria, Hpylori, StyphiO, StyphiH, StyphiVI, StparatyphiAO, StparatyphiAH, StparatyphiAVI, StparatyphiBO, StparatyphiBH, StparatyphiBVI, SparatyphiCO, SparatyphiCH, SparatyphiCVI)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material', '$ward', '$requestdate', '$docsign', '$fullbloodc', '$haemaPVC', '$haemoglobin', '$RBC', '$WBC', '$polys', '$lymp', '$monos', '$eosin', '$baso', '$baso1', '$mvc', '$mch', '$mchc', '$boxESR', '$ESR', '$boxRC', '$RC', '$boxhbgene', '$hbgene', '$boxsicklingtest', '$sicklingtest', '$boxBG', '$boxmalaria', '$boxhepatitisB', '$hepatitisB', '$boxhepatitisC', '$hepatitisC', '$boxHIV', '$HIV', '$boxVDRL', '$VDRL', '$boxHpylori', '$BG', '$malaria', '$Hpylori', '$StyphiO', '$StyphiH', '$StyphiVI', '$StparatyphiAO', '$StparatyphiAH', '$StparatyphiAVI', '$StparatyphiBO', '$StparatyphiBH', '$StparatyphiBVI', '$SparatyphiCO', '$SparatyphiCH', '$SparatyphiCVI')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['bacteriology'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $marijana = $_POST['marijana'];
  $cocaine = $_POST['cocaine'];
  $benzo = $_POST['benzo'];
  $tricy = $_POST['tricy'];
  $metha = $_POST['metha'];
  $opium = $_POST['opium'];
  $amphe = $_POST['amphe'];
  $metyl = $_POST['metyl'];
  $barbi = $_POST['barbi'];
  $trama = $_POST['trama'];
  $others = $_POST['other'];
  $comment = $_POST['comment'];
  $conclusion = $_POST['conclusion'];
  $doctorsign = $_POST['docsign'];
  $labsign = $_POST['medlab'];
  $request = $_POST['requestdate'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO toxicology (PatientID, viewID, clinician, diagnosis, material, marijana, cocaine, benzodiazephine, tricyclic_antidepressants, methadone, opium, amphetamine, metylene_dioxymethamphe, barbiturates, tramadol, others, comment, conclusion, doctorsign, labsign, requestDate, resultDate)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material', '$marijana', '$cocaine', '$benzo', '$tricy', '$metha', '$opium', '$amphe', '$metyl', '$barbi', '$trama', '$others', '$comment', '$conclusion', '$docid', '$labsign', '$request', '$labdate')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['urinalysis'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $marijana = $_POST['marijana'];
  $cocaine = $_POST['cocaine'];
  $benzo = $_POST['benzo'];
  $tricy = $_POST['tricy'];
  $metha = $_POST['metha'];
  $opium = $_POST['opium'];
  $amphe = $_POST['amphe'];
  $metyl = $_POST['metyl'];
  $barbi = $_POST['barbi'];
  $trama = $_POST['trama'];
  $others = $_POST['other'];
  $comment = $_POST['comment'];
  $conclusion = $_POST['conclusion'];
  $doctorsign = $_POST['docsign'];
  $labsign = $_POST['medlab'];
  $request = $_POST['requestdate'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO toxicology (PatientID, viewID, clinician, diagnosis, material, marijana, cocaine, benzodiazephine, tricyclic_antidepressants, methadone, opium, amphetamine, metylene_dioxymethamphe, barbiturates, tramadol, others, comment, conclusion, doctorsign, labsign, requestDate, resultDate)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material', '$marijana', '$cocaine', '$benzo', '$tricy', '$metha', '$opium', '$amphe', '$metyl', '$barbi', '$trama', '$others', '$comment', '$conclusion', '$docid', '$labsign', '$request', '$labdate')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['toxicology'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $marijana = $_POST['marijana'];
  $cocaine = $_POST['cocaine'];
  $benzo = $_POST['benzo'];
  $tricy = $_POST['tricy'];
  $metha = $_POST['metha'];
  $opium = $_POST['opium'];
  $amphe = $_POST['amphe'];
  $metyl = $_POST['metyl'];
  $barbi = $_POST['barbi'];
  $trama = $_POST['trama'];
  $others = $_POST['other'];
  $comment = $_POST['comment'];
  $conclusion = $_POST['conclusion'];
  $doctorsign = $_POST['docsign'];
  $labsign = $_POST['medlab'];
  $request = $_POST['requestdate'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO toxicology (PatientID, viewID, clinician, diagnosis, material, marijana, cocaine, benzodiazephine, tricyclic_antidepressants, methadone, opium, amphetamine, metylene_dioxymethamphe, barbiturates, tramadol, others, comment, conclusion, doctorsign, labsign, requestDate, resultDate)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material', '$marijana', '$cocaine', '$benzo', '$tricy', '$metha', '$opium', '$amphe', '$metyl', '$barbi', '$trama', '$others', '$comment', '$conclusion', '$docid', '$labsign', '$request', '$labdate')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

?>
<script language="javascript" type="text/javascript">
  function f2() {
    window.close();
  }
  ser

  function f3() {
    window.print();
  }
</script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <title>Uploaded Result</title>
  <link href="style.css" rel="stylesheet" type="text/css" />
  <link href="anuj.css" rel="stylesheet" type="text/css">

  <link href="css/layout.css" rel="stylesheet" type="text/css" />
  <link media="screen" charset="utf-8" rel="stylesheet" href="css/base.css" />
  <link media="screen" charset="utf-8" rel="stylesheet" href="css/skeleton.css" />
  <link media="screen" charset="utf-8" rel="stylesheet" href="css/child.css" />
  <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />

  <link rel="stylesheet" type="text/css" href="theme.css" />
  <link rel="stylesheet" type="text/css" href="premium.css" />
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="main.css">
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <link href="bootstrap/js/bootstrap.min.js" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <title>Toxicology</title>

  <script src="js/jquery-1.11.1.min.js" type="text/javascript"></script>
  <script type="text/javascript" language="javascript" src="js/jquery-1-8-2.js"></script>
  <script type="text/javascript" src="js/default.js"></script>
  <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
  <script type="text/javascript" src="js/jquery.carousel.js"></script>
  <script type="text/javascript" src="js/jquery.color.animation.js"></script>
  <script type="text/javascript" src="js/jquery.isotope.min.js"></script>
  <script type="text/javascript" src="js/jquery.prettyPhoto.js" charset="utf-8"></script>

</head>

<body>

  <div style="margin-left:50px;">

    <?php
    $vid = $_GET['viewid'];
    $pid = $_GET['pid'];

    //$rets = mysqli_query($con, "select * from tblmedicalhistory  where ID='" . $_GET['viewid'] . "'");
    //while ($row = mysqli_fetch_array($rets)) {

    $ret1 = mysqli_query($con, "select * FROM tblpatient where PatientID='" . $_GET['pid'] . "'");
    $rw = mysqli_fetch_array($ret1);
    if ($rw > 0) {
    ?>


      <div class="container">


        <H3 style="font-weight:bold;font-size:19px;"> Fill Lab Test for <?php echo $rw['PatientName']; ?></H3>
        <p style="color:red;"><?php echo htmlentities($_SESSION['msg']); ?>
          <?php echo htmlentities($_SESSION['msg'] = ""); ?></p>

        <br />


        <div class="filter">

          <ul id="filters" class="">
            <li><b><a href="" data-filter="#preg">Pregnancy Test</a></b></li>
            <li> <b><a href="" data-filter="#rad">Radiological Examination (xray)</a></b></li>
            <li><b><a href="" data-filter="#haema">Request-for-lab-haematology</a></b></li>
            <li><b><a href="" data-filter="#micro">Request-for-lab-micriobiolgy-bacteriology</a></b></li>
            <li><b><a href="" data-filter="#urinary">Request-for-laboratry-microbiology-urinalysis</a></b></li>
            <li><b><a href="" data-filter="#toxi">Toxicology</a></b></li>
          </ul>

          <div class="clear"></div>
        </div>
        <div class="portfolio standard one">
          <div id="isotope-container" class="portfolio-container">


            <!-- pregnancy Test Form -->
            <div class="item" id="preg">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  Request for Laboratory Services
                </h3>

                <h2>
                  PREGNANCY TEST
                </h2>


              </header>

              <body>

                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>
                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>TESTS</label><input type="text" class="form-control" placeholder="TESTS" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" class="form-control" placeholder="DATE OF REQUEST" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DR.</label><input type="text" class="form-control" placeholder="SIGNATURE OF DR." aria-label="Last name">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4>REPORT (for laboratory use only)</h4>
                    <div class="form-group">
                      <label for="exampleFormControlTextarea1">Report</label>
                      <textarea class="form-control" name="report" id="exampleFormControlTextarea1" rows="3"></textarea>
                    </div>
                  </div>
                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="pt" value="Submit">
                  </div>

                </form>

              </body>

            </div>


            <!-- Radiological Examination (xray) -->
            <div class="item" id="rad">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  Request for Laboratory Services
                </h3>

                <h2>
                  RADIOLOGICAL EXAMINATION
                </h2>


              </header>

              <body>

                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4>REPORT (for laboratory use only)</h4>
                    <h4>CLINICAL DIAGNOSIS WITH RELEVANT DETAILS FOR COMPLETION BY M.O:</h4>
                    <div class="row g-3">
                      <div class="col-4">
                        <label>PART OF THE BODY:</label>
                        <input type="text" class="form-control" placeholder="PART OF THE BODY" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>EXAMINATION REQUESTED</label> <input type="text" class="form-control" placeholder="EXAMINATION REQUESTED" aria-label="Last name">
                      </div>
                    </div>
                  </div>
                  <div class="container">
                    <h4>HAS THERE BEEN ANY OPERATION? Yes/No</h4>
                    <div class="row g-3">
                      <div class="col-4">
                        <input type="radio" name="OPERATION" value="yes">
                        <label for="YES">YES</label>
                        <input type="radio" name="OPERATION" value="no">
                        <label for="NO">NO</label><br>
                      </div>
                    </div>
                  </div>
                  <div class="container">
                    <div class="row g-3">
                      <div class="col-4">
                        <label style="font-size: small;"> X-RAY EXAMINATION? YES/NO.IF SO QUOTA X-RAY NUMBER:</label>
                        <input type="text" class="form-control" placeholder="X-RAY Number" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>M.O's NAME: </label> <input type="text" class="form-control" placeholder="M.O's NAME:" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>M.O's SIGNATURE: </label> <input type="text" class="form-control" placeholder="M.O's SIGNATURE:" aria-label="Last name">
                      </div>
                    </div>
                  </div>
                  <div class="container">
                    <h4 style="padding-top: 40px;font-weight: bolder;padding-left:2rem">WALKING CASE,CHAIR,TROLLEY,THEATRE,PORTABLE</h4>

                    <table style="width:100%;border: 1px solid black;max-width:100%;margin-top: 30px;margin-left:2rem">
                      <tr style="border: 1px solid black">
                        <th style="border: 1px solid black">""</th>
                        <th style="border: 1px solid black">""</th>

                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black">35 x 43cm</td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label></td>

                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black">35 x 35cm</td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label></td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black">30 x 40cm</td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label></td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black">24 x 30cm</td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label></td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black">18 x 24cm</td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label></td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label>Radiographer: <input name="Username" type="text" placeholder=""></label></td>
                        <td style="border: 1px solid black"><label>Checked by: <input name="Username" type="text" placeholder=""></label></td>
                      </tr>
                    </table>
                    <table style="width:100%;border: 1px solid black;max-width:100%;margin-top: 6rem;margin-left:2rem">
                      <tr style="border: 1px solid black">
                        <th style="border: 1px solid black">NOTES</th>
                        <th style="border: 1px solid black">RADIOLOGIST'S REPORT</th>

                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>

                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                    </table>
                  </div>
                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="radiology" value="Submit">
                  </div>
                </form>
              </body>
            </div>

            <!-- request-for-lab-haematology Form -->
            <div class="item" id="haema">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  Request for Laboratory Services
                </h3>

                <h2>
                  HEAMATOLOGY TEST
                </h2>


              </header>

              <body>

                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4>REPORT (for laboratory use only)</h4>

                    <h2><u> ROUTINE INVESTIGATIONS</u></h2>

                    <div class="row g-2">

                      <div class="col -6">

                        <div class="col-9">

                          <div>
                            <input type="checkbox" name="fullbloodc" placeholder="Full Blood Count">
                            <label>Full Blood Count</label>
                          </div>

                          <container class="container">

                            <label> &#8226; Haematocrit(PVC)</label><input type="text" name="haemaPVC" class="form-control" placeholder="(F:38-45%)  (M: 40-55%)">
                            <label> &#8226; Hamoglobin (HB)</label><input type="text" name="haemoglobin" class="form-control" placeholder="(F: 11 - 15g/dl) (M:13.5 - 16.5g/dl)">
                            <label> &#8226; Red Cell Count</label><input type="text" name="RBC" class="form-control" placeholder="(F:3.8 - 5.8 x 10^12 / l) (M:4.5 - 6.5 x 10^12 / l)">
                            <label> &#8226; White Cell Count</label><input type="text" name="WBC" class="form-control" placeholder="(2.5 - 10 x 10^9 / l)">
                            <label> WBC Differentials - Polys</label><input type="text" name="polys" class="form-control" placeholder="(45 - 55% )">
                            <label> WBC Differentials - Lymph</label><input type="text" name="lymp" class="form-control" placeholder="(25 - 55% )">
                            <label> WBC Differentials - Monos</label><input type="text" name="monos" class="form-control" placeholder="(1 - 6% )">
                            <label> WBC Differentials - Eosin</label><input type="text" name="eosin" class="form-control" placeholder="(1 - 8% )">
                            <label> WBC Differentials - Baso</label><input type="text" name="baso" class="form-control" placeholder="(0 - 1% )">
                            <label> WBC Differentials - Baso</label><input type="text" name="baso1" class="form-control" placeholder="">
                            <label> MCV </label><input type="text" name="mcv" class="form-control" placeholder="(76 - 96 fl)">
                            <label> MCH </label><input type="text" name="mch" class="form-control" placeholder="(27 - 32 pg)">
                            <label> MCHC </label><input type="text" name="mchc" class="form-control" placeholder="(32 - 36g/dl)">
                          </container>

                        </div>
                      </div>

                      <div class="col -6">

                        <div class="col-9">


                          <br />
                          <input type="checkbox" name="boxESR" placeholder=""> <label> ESR</label><input type="text" name="ESR" class="form-control" placeholder="(F:0-15mm/hr)  (M:0 - 7mm/hr)">
                          <input type="checkbox" name="boxRC" placeholder=""> <label> Reticulocyte Count</label><input type="text" name="reticulocyte" class="form-control" placeholder="(0 - 2%)">
                          <input type="checkbox" name="boxhbgene" placeholder=""> <label> Hb Genotype</label><input type="text" name="hbgene" class="form-control" placeholder="">
                          <input type="checkbox" name="boxsicklingtest" placeholder=""> <label> Sickling Test </label><input type="text" name="sicklingtest" class="form-control" placeholder="">
                          <input type="checkbox" name="boxBG" placeholder=""> <label> Blood Group</label><input type="text" name="BG" class="form-control" placeholder="">
                          <input type="checkbox" name="boxmalaria" placeholder=""> <label> Malaria Parasite</label><input type="text" name="malaria" class="form-control" placeholder="">
                          <input type="checkbox" name="boxhepatitisB" placeholder=""> <label> HEPATITIS B</label><input type="text" name="hepatitisB" class="form-control" placeholder="">
                          <input type="checkbox" name="boxhepatitisC" placeholder=""> <label> HEPATITIS C</label><input type="text" name="hepatitisC" class="form-control" placeholder="">
                          <input type="checkbox" name="boxHIV" placeholder=""> <label> HIV Screening</label><input type="text" name="HIV" class="form-control" placeholder="">
                          <input type="checkbox" name="boxVDRL" placeholder=""> <label> VDRL </label><input type="text" name="VDRL" class="form-control" placeholder="">
                          <input type="checkbox" name="boxHpylori" placeholder=""> <label> H. Pylori</label><input type="text" name="Hpylori" class="form-control" placeholder="">

                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="container">

                    <h2> WIDALAGG TEST REPORT </h2>

                    <div class="container">

                      <div class="row g-4">

                        <div class="col-6">
                          <label>S. typhi </label>
                        </div>

                        <div class="col-2">
                          <label> O </label>&#160; <input type="checkbox" name="StyphiO" placeholder="">
                        </div>

                        <div class="col-2">
                          <label>H</label>&#160;<input type="checkbox" name="StyphiH" placeholder="">
                        </div>

                        <div class="col-2">
                          <label>vi</label>&#160;<input type="checkbox" name="StyphiVI" placeholder="">
                        </div>
                      </div>

                    </div>

                    <div class="row g-4">

                      <div class="col-6">
                        <label>S. tparatyphi A</label>
                      </div>

                      <div class="col-2">
                        <label> O </label>&#160;<input type="checkbox" name="StparatyphiAO" placeholder="">
                      </div>

                      <div class="col-2">
                        <label>H</label>&#160;<input type="checkbox" name="StparatyphiAH" placeholder="">
                      </div>

                      <div class="col-2">
                        <label>vi</label>&#160;<input type="checkbox" name="StparatyphiAVI" placeholder="">
                      </div>

                    </div>

                    <div class="row g-4">

                      <div class="col-6">
                        <label>S. tparatyphi B</label>
                      </div>

                      <div class="col-2">
                        <label> O </label>&#160;<input type="checkbox" name="StparatyphiBO" placeholder="">
                      </div>

                      <div class="col-2">
                        <label>H</label>&#160;<input type="checkbox" name="StparatyphiBH" placeholder="">
                      </div>

                      <div class="col-2">
                        <label>vi</label>&#160;<input type="checkbox" name="StparatyphiBVI" placeholder="">
                      </div>

                    </div>
                    <div class="row g-4">

                      <div class="col-6">
                        <label>S. paratyphi C</label>
                      </div>

                      <div class="col-2">
                        <label> O </label>&#160;<input type="checkbox" name="SparatyphiCO" placeholder="">
                      </div>

                      <div class="col-2">
                        <label>H</label>&#160;<input type="checkbox" name="SparatyphiCH" placeholder="">
                      </div>

                      <div class="col-2">
                        <label>vi</label>&#160;<input type="checkbox" name="SparatyphiCVI" placeholder="">
                      </div>

                    </div>
                    <br />

                    <br />
                  </div>
                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="haematology" value="Submit">
                  </div>

                </form>

              </body>
            </div>

            <!-- request-for-lab-micriobiolgy-bacteriology Form -->
            <div class="item" id="micro">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  Request for Laboratory Services
                </h3>

                <h2>
                  MICROBIOLOGY
                  (Bacteriology)
                </h2>


              </header>

              <body>

                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4>REPORT (for laboratory use only)</h4>
                    <h4><u>HVS WET PREPARATION</u></h4>
                    <div class="input-group mb-3">
                      <span class="input-group-text">EPITHELIAL CELLS</span>
                      <input type="text" class="form-control" placeholder="EPITHELIAL CELLS" aria-label="Username">
                      <span class="input-group-text">PUS CELLS</span>
                      <input type="text" class="form-control" placeholder="PUS CELLS" aria-label="Server">
                      <span class="input-group-text">RED BLOOD CELLS</span>
                      <input type="text" class="form-control" placeholder="RED BLOOD CELLS" aria-label="Server">
                    </div>
                    <div class="input-group mb-3">
                      <span class="input-group-text">BACTERIA</span>
                      <input type="text" class="form-control" placeholder="BACTERIA" aria-label="Username">
                      <span class="input-group-text">YEAST CELLS</span>
                      <input type="text" class="form-control" placeholder="YEAST CELLS" aria-label="Server">
                      <span class="input-group-text">TRICHOMONAS VEGINALIS</span>
                      <input type="text" class="form-control" placeholder="TRICHOMONAS VEGINALIS" aria-label="Server">
                    </div>
                  </div>
                  <div class="container">
                    <h4><u>GRAM STAIN</u></h4>
                    <div class="input-group mb-3">
                      <span class="input-group-text">ZIEHL NELSEN STAIN</span>
                      <input type="text" class="form-control" placeholder="ZIEHL NELSEN STAIN" aria-label="Server">
                    </div>
                    <div class="container">
                      <div class="input-group mb-3">
                        <span class="input-group-text">
                          <h4>CULTURE INCLUDING BIOCHEMICAL TESTS:</h4>
                        </span>
                        <input type="text" class="form-control" placeholder="ZIEHL NELSEN STAIN" aria-label="Server">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4><u>SENSITIVITY</u></h4>
                    <div class="container1">
                      <table style="width:10%;border: 1px solid black;max-width:10%" id="table">
                        <tr style="border: 1px solid black">
                          <th style="border: 1px solid black">AUG</th>
                          <th style="border: 1px solid black">AMX</th>
                          <th style="border: 1px solid black">PEN</th>
                          <th style="border: 1px solid black">STREP</th>
                          <th style="border: 1px solid black">COT</th>
                          <th style="border: 1px solid black">N'FUR</th>
                          <th style="border: 1px solid black">CXC</th>
                          <th style="border: 1px solid black">ERY</th>
                          <th style="border: 1px solid black">CHLO</th>
                          <th style="border: 1px solid black">TET</th>
                          <th style="border: 1px solid black">SXT</th>
                          <th style="border: 1px solid black">GM</th>
                          <th style="border: 1px solid black">OFL</th>
                          <th style="border: 1px solid black">CAZ</th>
                          <th style="border: 1px solid black">NA</th>
                          <th style="border: 1px solid black">CRX</th>
                          <th style="border: 1px solid black">CPR</th>
                          <th style="border: 1px solid black">CXM</th>
                        </tr>
                        <tr style="border: 1px solid black">
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                        </tr>
                        <tr style="border: 1px solid black">
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                        </tr>
                        <tr style="border: 1px solid black">
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder="  "></label></td>
                        </tr>
                      </table>
                    </div>
                  </div>
                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="bacteriology" value="Submit">
                  </div>
                </form>

              </body>

            </div>


            <!-- request-for-laboratory-urinalysis Form -->
            <div class="item" id="urinary">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  URINALYSIS
                </h3>


              </header>

              <body>

                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4>Requests(For Laboratory Use Only)</h4>
                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>COLOUR AND APPEARANCE</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>NITRITE</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>REACTION(Ph)</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SPECIFIC GRAVITY</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>PROTEIN</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>ASCORBIC ACID</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>REDUCING SUBSTANCES(Sugar)</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>BILLIRUBIN</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>KETONE BODIES</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>UROBILINOGEN</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>BLOOD</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>

                    </div>

                  </div>

                  <div class="container">
                    <h4>MICROSCOPY</h4>
                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>EPITHELIAL CELLS</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>PUS CELLS/HPF</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>RBCs/hpf</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>BACTERIA</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>CRYSTALS</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>CASTS</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>YEASTS CELLS</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>TRICHOMONAS VAGINALIS</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>S.HAEMATOBIUM</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>AMORPHOUS DEBRIS</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>SPERMATOZOA</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>AMORPHOUS CRYSTALS</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SAMPLE COLLECTED BY</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>DATE</label><input type="date" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>TIME</label><input type="time" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>RECEIVED BY</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>DATE</label><input type="date" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>TIME</label><input type="time" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LOGGED BY</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>DATE</label><input type="date" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>TIME</label><input type="time" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>MED. LAB. SCIENTIST(Signature)</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>MED. LAB. SCIENTIST(Date)</label><input type="date" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="urinalysis" value="Submit">
                  </div>
                </form>

              </body>

            </div>

            <!-- toxicology Form -->
            <div class="item" id="toxi">


              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h2>
                  TOXICOLOGY TEST
                </h2>
              </header>

              <body>

                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>


                  <div class="container">
                    <h2>REPORT(for laboratory use only)</h2>
                    <div class="row g-3">
                      <div class="col-4">
                        <label>MARIJUANA(THC)</label><input type="text" name="marijana" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>COCAINE(COC)</label><input type="text" name="cocaine" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>BENZODIAZEPHINE(BZO)</label><input type="text" name="benzo" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>
                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>TRICYCLIC ANTIDEPRESSANTS(TCA)</label><input type="text" name="tricy" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>METHADONE(MTD)</label><input type="text" name="metha" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OPIUM(OPIC)</label><input type="text" name="opium" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>
                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>d-AMPHETAMINE(AMP)</label><input type="text" name="amphe" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>METYLENE DIOXYMETHAMPHE.(MDMA)</label><input type="text" name="metyl" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>BARBITURATES(BAR)</label><input type="text" name="barbi" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>TRAMADOL(TML)</label><input type="text" name="trama" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHERS</label><input type="text" name="other" class="form-control" placeholder="." aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>MED. LAB. SCIENTIST</label><input type="text" name="medlab" class="form-control" placeholder="Signature" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE</label><input type="date" name="labdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">
                    <div class="form-group">
                      <label for="exampleFormControlTextarea1">COMMENT</label>
                      <textarea class="form-control" name="comment" id="exampleFormControlTextarea1" rows="3"></textarea>
                    </div>
                  </div>

                  <div class="container">
                    <div class="form-group">
                      <label for="exampleFormControlTextarea1">CONCLUSION</label>
                      <textarea class="form-control" name="conclusion" id="exampleFormControlTextarea1" rows="3"></textarea>
                    </div>
                  </div>

                  <div class="container">
                    <div class="row g-3">
                      <div class="col">
                        <label>DIREC. MED SERVICES</label><input type="text" name="sign" class="form-control" placeholder="Signature" aria-label="#">
                      </div>
                    </div>
                  </div>

                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="toxicology" value="Submit">
                  </div>

                </form>

              </body>
            </div>


          </div>
        </div>
      </div>
  </div>

  <tr>
    <td colspan="2">
      <input name="Submit2" type="submit" class="txtbox4" value="Close this window " onClick="return f2();" style="cursor: pointer;" />
    </td>
  </tr>
<?php } ?>
</div>

<script type="text/javascript">
  $(document).ready(function() {
    $('.slidewrap2').carousel({
      slider: '.slider',
      slide: '.slide',
      slideHed: '.slidehed',
      nextSlide: '.next',
      prevSlide: '.prev',
      addPagination: false,
      addNav: false
    });
  });
  $(window).load(function() {
    $("a[class^='prettyPhoto']").prettyPhoto({
      social_tools: ''
    });
    // cache container
    var $container = $('#isotope-container');
    // initialize isotope
    $container.isotope({
      animationOptions: {
        duration: 750,
        easing: 'linear',
        queue: false
      },
      layoutMode: 'fitRows'
    });
    // filter items when filter link is clicked
    $('#filters a').click(function() {
      $("#filters a.active").removeClass('active');
      $(this).addClass('active');
      var selector = $(this).attr('data-filter');
      $container.isotope({
        filter: selector
      });
      return false;
    });
  });
</script>

</body>

</html>