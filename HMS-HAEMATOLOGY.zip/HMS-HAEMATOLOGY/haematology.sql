-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2021 at 04:54 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `haematology`
--

-- --------------------------------------------------------

--
-- Table structure for table `haematology`
--

CREATE TABLE `haematology` (
  `id` int(11) NOT NULL,
  `PatientID` int(9) NOT NULL,
  `viewID` int(11) NOT NULL,
  `clinician` varchar(250) NOT NULL,
  `diagnosis` varchar(250) NOT NULL,
  `material` varchar(250) NOT NULL,
  `ward` varchar(250) NOT NULL,
  `requestdate` date NOT NULL,
  `docsign` varchar(250) NOT NULL,
  `fullbloodc` int(1) NOT NULL,
  `haemaPVC` varchar(250) NOT NULL,
  `haemoglobin` varchar(250) NOT NULL,
  `RBC` varchar(250) NOT NULL,
  `WBC` varchar(250) NOT NULL,
  `polys` varchar(250) NOT NULL,
  `lymp` varchar(250) NOT NULL,
  `monos` varchar(250) NOT NULL,
  `eosin` varchar(250) NOT NULL,
  `baso` varchar(250) NOT NULL,
  `baso1` varchar(250) NOT NULL,
  `mvc` varchar(250) NOT NULL,
  `mch` varchar(250) NOT NULL,
  `mchc` varchar(250) NOT NULL,
  `boxESR` int(1) NOT NULL,
  `ESR` int(250) NOT NULL,
  `boxRC` int(1) NOT NULL,
  `RC` int(250) NOT NULL,
  `boxhbgene` int(1) NOT NULL,
  `hbgene` int(250) NOT NULL,
  `boxsicklingtest` int(1) NOT NULL,
  `sicklingtest` varchar(250) NOT NULL,
  `boxBG` int(1) NOT NULL,
  `boxmalaria` int(250) NOT NULL,
  `boxhepatitisB` int(1) NOT NULL,
  `hepatitisB` varchar(250) NOT NULL,
  `boxhepatitisC` int(1) NOT NULL,
  `hepatitisC` varchar(250) NOT NULL,
  `boxHIV` int(1) NOT NULL,
  `HIV` varchar(250) NOT NULL,
  `boxVDRL` int(1) NOT NULL,
  `VDRL` varchar(250) NOT NULL,
  `boxHpylori` int(1) NOT NULL,
  `BG` varchar(250) NOT NULL,
  `malaria` varchar(250) NOT NULL,
  `Hpylori` varchar(250) NOT NULL,
  `StyphiO` int(1) NOT NULL,
  `StyphiH` int(1) NOT NULL,
  `StyphiVI` int(1) NOT NULL,
  `StparatyphiAO` int(1) NOT NULL,
  `StparatyphiAH` int(1) NOT NULL,
  `StparatyphiAVI` int(1) NOT NULL,
  `StparatyphiBO` int(1) NOT NULL,
  `StparatyphiBH` int(1) NOT NULL,
  `StparatyphiBVI` int(1) NOT NULL,
  `SparatyphiCO` int(1) NOT NULL,
  `SparatyphiCH` int(1) NOT NULL,
  `SparatyphiCVI` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `haematology`
--
ALTER TABLE `haematology`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `haematology`
--
ALTER TABLE `haematology`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
