-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 09, 2021 at 06:11 PM
-- Server version: 8.0.23-0ubuntu0.20.04.1
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `urinalysis`
--

-- --------------------------------------------------------

--
-- Table structure for table `urinalysis`
--

CREATE TABLE `urinalysis` (
  `id` int NOT NULL,
  `PatientID` int NOT NULL,
  `viewID` int NOT NULL,
  `clinician` varchar(250) NOT NULL,
  `diagnosis` varchar(250) NOT NULL,
  `material` varchar(250) NOT NULL,
  `color_app` varchar(250) NOT NULL,
  `nitrite` varchar(250) NOT NULL,
  `reaction` varchar(250) NOT NULL,
  `spe_gra` varchar(250) NOT NULL,
  `protein` varchar(250) NOT NULL,
  `asc_acid` varchar(250) NOT NULL,
  `red_sub` varchar(250) NOT NULL,
  `billi` varchar(250) NOT NULL,
  `ket_bodies` varchar(250) NOT NULL,
  `urob` varchar(250) NOT NULL,
  `blood` varchar(250) NOT NULL,
  `ephit` varchar(250) NOT NULL,
  `pus_hcf` varchar(250) NOT NULL,
  `rbc_hpf` varchar(250) NOT NULL,
  `bacteria` varchar(250) NOT NULL,
  `crystals` varchar(250) NOT NULL,
  `casts` varchar(250) NOT NULL,
  `yeast_cells` varchar(250) NOT NULL,
  `tric_vag` varchar(250) NOT NULL,
  `s_hae` varchar(250) NOT NULL,
  `amp_deb` varchar(250) NOT NULL,
  `spe` varchar(250) NOT NULL,
  `amo_cry` varchar(250) NOT NULL,
  `doctorsign` varchar(250) NOT NULL,
  `labsign` varchar(250) NOT NULL,
  `requestDate` date NOT NULL,
  `resultDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `urinalysis`
--
ALTER TABLE `urinalysis`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `urinalysis`
--
ALTER TABLE `urinalysis`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
