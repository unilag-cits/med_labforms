<?php
session_start();
error_reporting(0);
include 'include/config.php';
include 'include/checklogin.php';
check_login();

if (isset($_POST['pt'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $marijana = $_POST['marijana'];
  $cocaine = $_POST['cocaine'];
  $benzo = $_POST['benzo'];
  $tricy = $_POST['tricy'];
  $metha = $_POST['metha'];
  $opium = $_POST['opium'];
  $amphe = $_POST['amphe'];
  $metyl = $_POST['metyl'];
  $barbi = $_POST['barbi'];
  $trama = $_POST['trama'];
  $others = $_POST['other'];
  $comment = $_POST['comment'];
  $conclusion = $_POST['conclusion'];
  $doctorsign = $_POST['docsign'];
  $labsign = $_POST['medlab'];
  $request = $_POST['requestdate'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO toxicology (PatientID, viewID, clinician, diagnosis, material, marijana, cocaine, benzodiazephine, tricyclic_antidepressants, methadone, opium, amphetamine, metylene_dioxymethamphe, barbiturates, tramadol, others, comment, conclusion, doctorsign, labsign, requestDate, resultDate)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material', '$marijana', '$cocaine', '$benzo', '$tricy', '$metha', '$opium', '$amphe', '$metyl', '$barbi', '$trama', '$others', '$comment', '$conclusion', '$docid', '$labsign', '$request', '$labdate')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['radiology'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $marijana = $_POST['marijana'];
  $cocaine = $_POST['cocaine'];
  $benzo = $_POST['benzo'];
  $tricy = $_POST['tricy'];
  $metha = $_POST['metha'];
  $opium = $_POST['opium'];
  $amphe = $_POST['amphe'];
  $metyl = $_POST['metyl'];
  $barbi = $_POST['barbi'];
  $trama = $_POST['trama'];
  $others = $_POST['other'];
  $comment = $_POST['comment'];
  $conclusion = $_POST['conclusion'];
  $doctorsign = $_POST['docsign'];
  $labsign = $_POST['medlab'];
  $request = $_POST['requestdate'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO toxicology (PatientID, viewID, clinician, diagnosis, material, marijana, cocaine, benzodiazephine, tricyclic_antidepressants, methadone, opium, amphetamine, metylene_dioxymethamphe, barbiturates, tramadol, others, comment, conclusion, doctorsign, labsign, requestDate, resultDate)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material', '$marijana', '$cocaine', '$benzo', '$tricy', '$metha', '$opium', '$amphe', '$metyl', '$barbi', '$trama', '$others', '$comment', '$conclusion', '$docid', '$labsign', '$request', '$labdate')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['heamatology'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $marijana = $_POST['marijana'];
  $cocaine = $_POST['cocaine'];
  $benzo = $_POST['benzo'];
  $tricy = $_POST['tricy'];
  $metha = $_POST['metha'];
  $opium = $_POST['opium'];
  $amphe = $_POST['amphe'];
  $metyl = $_POST['metyl'];
  $barbi = $_POST['barbi'];
  $trama = $_POST['trama'];
  $others = $_POST['other'];
  $comment = $_POST['comment'];
  $conclusion = $_POST['conclusion'];
  $doctorsign = $_POST['docsign'];
  $labsign = $_POST['medlab'];
  $request = $_POST['requestdate'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO toxicology (PatientID, viewID, clinician, diagnosis, material, marijana, cocaine, benzodiazephine, tricyclic_antidepressants, methadone, opium, amphetamine, metylene_dioxymethamphe, barbiturates, tramadol, others, comment, conclusion, doctorsign, labsign, requestDate, resultDate)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material', '$marijana', '$cocaine', '$benzo', '$tricy', '$metha', '$opium', '$amphe', '$metyl', '$barbi', '$trama', '$others', '$comment', '$conclusion', '$docid', '$labsign', '$request', '$labdate')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['bacteriology'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $ward = $_POST['ward'];
  $docsign = $_POST['docsign'];
  $EPITHELIALCELLS = $_POST['EPITHELIALCELLS'];
  $PUSCELLS = $_POST['PUSCELLS'];
  $RedBloodCells = $_POST['RedBloodCells'];
  $BACTERIA = $_POST['BACTERIA'];
  $YeastCells = $_POST['YeastCells'];
  $ZiehlNelsenStain = $_POST['ZiehlNelsenStain'];
  $TRICHOMONAS = $_POST['TRICHOMONAS'];
  $CULTURE = $_POST['CULTURE'];
  $AUG1 = $_POST['AUG1'];
  $AUG2 = $_POST['AUG2'];
  $AUG3 = $_POST['AUG3'];
  $AMX1 = $_POST['AMX1'];
  $AMX2 = $_POST['AMX2'];
  $AMX3 = $_POST['AMX3'];
  $STREP1 = $_POST['STREP1'];
  $STREP2 = $_POST['STREP2'];
  $STREP3 = $_POST['STREP3'];
  $NFUR = $_POST['NFUR'];
  $NFUR = $_POST['NFUR'];
  $NFUR = $_POST['NFUR'];
  $CXC1 = $_POST['CXC1'];
  $CXC2 = $_POST['CXC2'];
  $CXC3 = $_POST['CXC3'];
  $ERY1 = $_POST['ERY1'];
  $ERY2 = $_POST['ERY2'];
  $ERY3 = $_POST['ERY3'];
  $CHLO1 = $_POST['CHLO1'];
  $CHLO2 = $_POST['CHLO2'];
  $CHLO3 = $_POST['CHLO3'];
  $TET1 = $_POST['TET1'];
  $TET2 = $_POST['TET2'];
  $TET3 = $_POST['TET3'];
  $SXT1 = $_POST['SXT1'];
  $SXT2 = $_POST['SXT2'];
  $SXT3 = $_POST['SXT3'];
  $GM1 = $_POST['GM1'];
  $GM2 = $_POST['GM2'];
  $GM3 = $_POST['GM3'];
  $OFL1 = $_POST['OFL1'];
  $OFL2 = $_POST['OFL2'];
  $OFL3 = $_POST['OFL3'];
  $CAZ1 = $_POST['CAZ1'];
  $CAZ2 = $_POST['CAZ2'];
  $CAZ3 = $_POST['CAZ3'];
  $NA1 = $_POST['NA1'];
  $NA2 = $_POST['NA2'];
  $NA3 = $_POST['NA3'];
  $CRX1 = $_POST['CRX1'];
  $CRX2 = $_POST['CRX2'];
  $CRX3 = $_POST['CRX3'];
  $CPR1 = $_POST['CPR1'];
  $CPR2 = $_POST['CPR2'];
  $CPR3 = $_POST['CPR3'];
  $CXM1 = $_POST['CXM1'];
  $CXM2 = $_POST['CXM2'];
  $CXM3 = $_POST['CXM3'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO bacteriology (`id`, `PatientID`, `viewID`, `clinician`, `diagnosis`, `material`, `ward`, `requestDate`, `docsign`, `EPITHELIALCELLS `, `PUSCELLS`, `RedBloodCells`, `BACTERIA`, `YeastCells`, `ZiehlNelsenStain`, `TRICHOMONAS`, `CULTURE`, `AUG1`, `AUG2`, `AUG3`, `AMX1`, `AMX2`, `AMX3`, `STREP1`, `STREP2`, `STREP3`, `NFUR1`, `NFUR2`, `NFUR3`,`CXC1`, `CXC2`, `CXC3`, `ERY1`, `ERY2`, `ERY3`, `CHLO1`, `CHLO2`, `CHLO3`, `TET1`, `TET2`, `TET3`, `SXT1`, `SXT2`, `SXT3`, `GM1`, `GM2`, `GM3`, `OFL1`, `OFL2`, `OFL3`, `CAZ1`, `CAZ2`, `CAZ3`, `NA1`, `NA2`, `NA3`, `CRX1`, `CRX2`, `CRX3`, `CPR1`, `CPR2`, `CPR3`, `CXM1`, `CXM2`, `CXM3`))
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "',  `$clinician`, `$diagnosis`, `$material`, `$ward`, `$requestDate`, `$docsign`, `$EPITHELIALCELLS `, `$PUSCELLS`, `$RedBloodCells`, `$BACTERIA`, `$YeastCells`, `$ZiehlNelsenStain`, `$TRICHOMONAS`, `$CULTURE`, `$AUG1`, `$AUG2`, `$AUG3`, `$AMX1`, `$AMX2`, `$AMX3`, `$STREP1`, `$STREP2`, `$STREP3`, `$NFUR1`, `$NFUR2`, `$NFUR3`,`$CXC1`, $`CXC2`, `$CXC3`, `$ERY1`, `$ERY2`, `$ERY3`, `$CHLO1`, `$CHLO2`, `$CHLO3`, `$TET1`, `$TET2`, `$TET3`, `$SXT1`, `$SXT2`, `$SXT3`, `$GM1`, `$GM2`, `$GM3`, `$OFL1`, `$OFL2`, `$OFL3`, `$CAZ1`, `$CAZ2`, `$CAZ3`, `$NA1`, `$NA2`, `$NA3`, `$CRX1`, `$CRX2`, `$CRX3`, `$CPR1`, `$CPR2`, `$CPR3`, `$CXM1`, `$CXM2`, `$CXM3`)");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['urinalysis'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $marijana = $_POST['marijana'];
  $cocaine = $_POST['cocaine'];
  $benzo = $_POST['benzo'];
  $tricy = $_POST['tricy'];
  $metha = $_POST['metha'];
  $opium = $_POST['opium'];
  $amphe = $_POST['amphe'];
  $metyl = $_POST['metyl'];
  $barbi = $_POST['barbi'];
  $trama = $_POST['trama'];
  $others = $_POST['other'];
  $comment = $_POST['comment'];
  $conclusion = $_POST['conclusion'];
  $doctorsign = $_POST['docsign'];
  $labsign = $_POST['medlab'];
  $request = $_POST['requestdate'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO toxicology (PatientID, viewID, clinician, diagnosis, material, marijana, cocaine, benzodiazephine, tricyclic_antidepressants, methadone, opium, amphetamine, metylene_dioxymethamphe, barbiturates, tramadol, others, comment, conclusion, doctorsign, labsign, requestDate, resultDate)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material', '$marijana', '$cocaine', '$benzo', '$tricy', '$metha', '$opium', '$amphe', '$metyl', '$barbi', '$trama', '$others', '$comment', '$conclusion', '$docid', '$labsign', '$request', '$labdate')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['toxicology'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $marijana = $_POST['marijana'];
  $cocaine = $_POST['cocaine'];
  $benzo = $_POST['benzo'];
  $tricy = $_POST['tricy'];
  $metha = $_POST['metha'];
  $opium = $_POST['opium'];
  $amphe = $_POST['amphe'];
  $metyl = $_POST['metyl'];
  $barbi = $_POST['barbi'];
  $trama = $_POST['trama'];
  $others = $_POST['other'];
  $comment = $_POST['comment'];
  $conclusion = $_POST['conclusion'];
  $doctorsign = $_POST['docsign'];
  $labsign = $_POST['medlab'];
  $request = $_POST['requestdate'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO toxicology (PatientID, viewID, clinician, diagnosis, material, marijana, cocaine, benzodiazephine, tricyclic_antidepressants, methadone, opium, amphetamine, metylene_dioxymethamphe, barbiturates, tramadol, others, comment, conclusion, doctorsign, labsign, requestDate, resultDate)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material', '$marijana', '$cocaine', '$benzo', '$tricy', '$metha', '$opium', '$amphe', '$metyl', '$barbi', '$trama', '$others', '$comment', '$conclusion', '$docid', '$labsign', '$request', '$labdate')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['microbiologyurine'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $ward = $_POST['ward'];
  $docsign = $_POST['docsign'];
  $requestdate = $_POST['requestdate'];
  $puscells = $_POST['puscells'];
  $rbcs = $_POST['rbcs'];
  $epithcell = $_POST['epithcell'];
  $bacteria = $_POST['bacteria'];
  $Yeast = $_POST['Yeast'];
  $casts = $_POST['casts'];
  $amorphous = $_POST['amorphous'];
  $crystals = $_POST['crystals'];
  $spermatozoa = $_POST['spermatozoa'];
  $puscount = $_POST['puscount'];
  $pusml = $_POST['pusml'];
  $ziehlstain = $_POST['ziehlstain'];
  $AUG1 = $_POST['AUG1'];
  $AUG2 = $_POST['AUG2'];
  $AUG3 = $_POST['AUG3'];
  $AMX1 = $_POST['AMX1'];
  $AMX2 = $_POST['AMX2'];
  $AMX3 = $_POST['AMX3'];
  $STREP1 = $_POST['STREP1'];
  $STREP2 = $_POST['STREP2'];
  $STREP3 = $_POST['STREP3'];
  $NFUR = $_POST['NFUR'];
  $NFUR = $_POST['NFUR'];
  $NFUR = $_POST['NFUR'];
  $CXC1 = $_POST['CXC1'];
  $CXC2 = $_POST['CXC2'];
  $CXC3 = $_POST['CXC3'];
  $ERY1 = $_POST['ERY1'];
  $ERY2 = $_POST['ERY2'];
  $ERY3 = $_POST['ERY3'];
  $CHLO1 = $_POST['CHLO1'];
  $CHLO2 = $_POST['CHLO2'];
  $CHLO3 = $_POST['CHLO3'];
  $TET1 = $_POST['TET1'];
  $TET2 = $_POST['TET2'];
  $TET3 = $_POST['TET3'];
  $SXT1 = $_POST['SXT1'];
  $SXT2 = $_POST['SXT2'];
  $SXT3 = $_POST['SXT3'];
  $GM1 = $_POST['GM1'];
  $GM2 = $_POST['GM2'];
  $GM3 = $_POST['GM3'];
  $OFL1 = $_POST['OFL1'];
  $OFL2 = $_POST['OFL2'];
  $OFL3 = $_POST['OFL3'];
  $CAZ1 = $_POST['CAZ1'];
  $CAZ2 = $_POST['CAZ2'];
  $CAZ3 = $_POST['CAZ3'];
  $NA1 = $_POST['NA1'];
  $NA2 = $_POST['NA2'];
  $NA3 = $_POST['NA3'];
  $CRX1 = $_POST['CRX1'];
  $CRX2 = $_POST['CRX2'];
  $CRX3 = $_POST['CRX3'];
  $CPR1 = $_POST['CPR1'];
  $CPR2 = $_POST['CPR2'];
  $CPR3 = $_POST['CPR3'];
  $CXM1 = $_POST['CXM1'];
  $CXM2 = $_POST['CXM2'];
  $CXM3 = $_POST['CXM3'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO microbiologyurine (`id`, `PatientID`, `viewID`, `clinician`, `diagnosis`, `material`, `ward`, `docsign`, `requestDate`, 'puscells', 'rbcs', 'epithcell', 'bacteria', 'yeast', 'casts', 'amorphous', 'crystals', 'spermatozoa', 'puscount', 'pusml', 'ziehlstain', `AUG1`, `AUG2`, `AUG3`, `AMX1`, `AMX2`, `AMX3`, `STREP1`, `STREP2`, `STREP3`, `NFUR1`, `NFUR2`, `NFUR3`,`CXC1`, `CXC2`, `CXC3`, `ERY1`, `ERY2`, `ERY3`, `CHLO1`, `CHLO2`, `CHLO3`, `TET1`, `TET2`, `TET3`, `SXT1`, `SXT2`, `SXT3`, `GM1`, `GM2`, `GM3`, `OFL1`, `OFL2`, `OFL3`, `CAZ1`, `CAZ2`, `CAZ3`, `NA1`, `NA2`, `NA3`, `CRX1`, `CRX2`, `CRX3`, `CPR1`, `CPR2`, `CPR3`, `CXM1`, `CXM2`, `CXM3`))
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "',  `$clinician`, `$diagnosis`, `$material`, `$ward`, `$docsign`, `$requestDate`, '$puscells', '$rbcs', '$epithcell', '$bacteria', '$yeast', '$casts', '$amorphous', '$crystals', '$spermatozoa', '$puscount', '$pusml', '$ziehlstain', `$AUG1`, `$AUG2`, `$AUG3`, `$AMX1`, `$AMX2`, `$AMX3`, `$STREP1`, `$STREP2`, `$STREP3`, `$NFUR1`, `$NFUR2`, `$NFUR3`,`$CXC1`, $`CXC2`, `$CXC3`, `$ERY1`, `$ERY2`, `$ERY3`, `$CHLO1`, `$CHLO2`, `$CHLO3`, `$TET1`, `$TET2`, `$TET3`, `$SXT1`, `$SXT2`, `$SXT3`, `$GM1`, `$GM2`, `$GM3`, `$OFL1`, `$OFL2`, `$OFL3`, `$CAZ1`, `$CAZ2`, `$CAZ3`, `$NA1`, `$NA2`, `$NA3`, `$CRX1`, `$CRX2`, `$CRX3`, `$CPR1`, `$CPR2`, `$CPR3`, `$CXM1`, `$CXM2`, `$CXM3`)");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['stooltest'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $watery = $_POST['watery'];
  $formed = $_POST['formed'];
  $mucus = $_POST['mucus'];
  $uinformed = $_POST['uniformed'];
  $hardformed = $_POST['hardformed'];
  $noblood = $_POST['noblood'];
  $softformed = $_POST['softformed'];
  $nomucus = $_POST['nomucus'];
  $withblood = $_POST['withblood'];
  $ascaris = $_POST['ascaris'];
  $trichoris = $_POST['trichoris'];
  $schistosoma = $_POST['schistosoma'];
  $tapeworm = $_POST['tapeworm'];
  $trichomanas = $_POST['trichomanas'];
  $ehistolytica = $_POST['ehistolytica'];
  $ecoli = $_POST['ecoli'];
  $stecoralis = $_POST['stecoralis'];
  $puscells = $_POST['puscells'];
  $recs = $_POST['recs'];
  $charcrystals = $_POST['charcrystals'];
  $ovaprotozoa = $_POST['ovaprotozoa'];
  $othertest = $_POST['othertest'];
  $occultblood = $_POST['occultblood'];
  $doctorsign = $_POST['docsign'];
  $labsign = $_POST['medlab'];
  $request = $_POST['requestdate'];
  $labdate = $_POST['labdate'];
  $currentTime = date('Y-m-d h:i:s A', time());

  $query = mysqli_query($con, "INSERT INTO stooltest (PatientID, viewID, clinician, diagnosis, material, watery, formed, mucus, uniformed, hardformed, noblood, softformed, nomucus, withblood, ascaris, trichoris, schistomanas, tapeworm, trichomanas, ehistolytica, ecoli, stecoralis, puscells, recs, charcrystals, ovaprotozoa, othertest, occultblood, doctorsign, labsign, requestDate, resultDate)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material',  '$watery', '$formed', '$mucus', '$uniformed', '$hardformed', '$noblood', '$softformed', '$nomucus', '$withblood', '$ascaris', '$trichoris', '$schitomanas', '$tapeworm', '$trichomanas', '$ehistolytica', '$ecoli', '$stecoralis', '$puscells', '$recs', '$charcrystals', '$ovaprotozoa', '$othertest', '$occultblood', '$docid', '$labsign', '$request', '$labdate')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['clichem'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $ward = $_POST['ward'];
  $requestdate = $_POST['requestdate'];
  $docsign = $_POST['docsign'];
  $bicarbonbox = $_POST['bicarbonbox'];
  $chloridebox = $_POST['chloridebox'];
  $sodiumbox = $_POST['sodiumbox'];
  $potasbox = $_POST['potasbox'];
  $ureabox = $_POST['ureabox'];
  $serumbox = $_POST['serumbox'];
  $creatbox = $_POST['creatbox'];
  $uricbox = $_POST['uricbox'];
  $totprobox = $_POST['totprobox'];
  $albuminbox = $_POST['albuminbox'];
  $bicarbon = $_POST['bicarbon'];
  $chloride = $_POST['chloride'];
  $sodium = $_POST['sodium'];
  $potas = $_POST['potas'];
  $urea = $_POST['urea'];
  $serum = $_POST['serum'];
  $creat = $_POST['creat'];
  $uric = $_POST['uric'];
  $totpro = $_POST['totpro'];
  $albumin = $_POST['albumin'];
  $aspbox = $_POST['aspbox'];
  $alaninebox = $_POST['alaninebox'];
  $alkabox = $_POST['alkabox'];
  $tbillibox = $_POST['tbillibox'];
  $dbillibox = $_POST['dbillibox'];
  $asp = $_POST['asp'];
  $alanine = $_POST['alanine'];
  $alka = $_POST['alka'];
  $tbilli = $_POST['tbilli'];
  $dbilli = $_POST['dbilli'];
  $glucosebox = $_POST['glucosebox'];
  $hppbox = $_POST['hppbox'];
  $rbsbox = $_POST['rbsbox'];
  $hba1box = $_POST['hba1box'];
  $hba2box = $_POST['hba2box'];
  $gtoltextbox = $_POST['gtoltextbox'];
  $glucose = $_POST['glucose'];
  $hpp = $_POST['hpp'];
  $rbsbox = $_POST['rbs'];
  $hba1 = $_POST['hba1'];
  $hba2 = $_POST['hba2'];
  $gtoltext = $_POST['gtoltext'];
  $totalcholbox = $_POST['totalcholbox'];
  $hdlbox = $_POST['hdlbox'];
  $ldlbox = $_POST['ldlbox'];
  $vldlbox = $_POST['vldlbox'];
  $trigbox = $_POST['trigbox'];
  $psabox = $_POST['psabox'];
  $othersbox = $_POST['othersbox'];
  $totalchol = $_POST['totalchol'];
  $hdl = $_POST['hdl'];
  $ldl = $_POST['ldl'];
  $vldl = $_POST['vldl'];
  $trig = $_POST['trig'];
  $psa = $_POST['psa'];
  $others = $_POST['others'];
  $comments = $_POST['comments'];
  $sign = $_POST['sign'];
  $meddate = $_POST['meddate'];
  $currentTime = date('Y-m-d h:i:s A', time());
  $query = mysqli_query($con, "INSERT INTO clichem (PatientID, viewID, clinician, diagnosis, material, ward, requesddate, docsign, bicarbonbox, chloridebox, sodiumbox, potasbox, ureabox, serumbox, creatbox, uricbox, totprobox, albuminbox, bicardon, chloride, sodium, potas, urea, serum, creat, uric, totpro, albumin, aspbox, alaniniebox, alkabox, tbllibox, dbilliox, asp, alaninine, alka,  tbilli, dbilli, glucosebox, hppbox, rbsbox, hba1box, hba2box, gtoltextbox, glucose, hpp, rbs, hba1, hba2, gtoltext, totalcholbox, hdlbox, ldlbox, vldlbox,trigbox, psabox, othersbox, totalchol, hdl, ldl, vldl, trig, psa, others, comments, 'sign', meddate)
           VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material',  '$ward', '$requesddate', '$docsign', '$bicarbonbox', '$chloridebox', '$sodiumbox', '$potasbox', '$ureabox', '$serumbox', '$creatbox', '$uricbox', '$totprobox', '$albuminbox', '$bicardon', '$chloride', '$sodium', '$potas', '$urea', '$serum', '$creat', '$uric', '$totpro', '$albumin', '$aspbox', '$alaniniebox', '$alkabox', '$tbllibox', '$dbilliox', '$asp', '$alaninine', '$alka',  '$tbilli', '$dbilli', '$glucosebox', '$hppbox', '$rbsbox', '$hba1box', '$hba2box', '$gtoltextbox', '$glucose', '$hpp', '$rbs', '$hba1', '$hba2', '$gtoltext', '$totalcholbox', '$hdlbox', '$ldlbox', '$vldlbox', '$trigbox, '$psabox', '$othersbox', '$totalchol', '$hdl', '$ldl', '$vldl', '$trig', '$psa', '$others', '$comments', '$sign', '$meddate')");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

if (isset($_POST['microsem'])) {
  $docid = $_GET['docid'];
  $pid = $_GET['pid'];
  $clinician = $_POST['clinician'];
  $diagnosis = $_POST['diagnosis'];
  $material = $_POST['material'];
  $ward = $_POST['ward'];
  $requestdate = $_POST['requestdate'];
  $docsign = $_POST['docsign'];
  $timecollected = $_POST['timecollected'];
  $timereceived = $_POST['timereceived'];
  $timeexa = $_POST['timeexa'];
  $method = $_POST['method'];
  $abstinence = $_POST['abstinence'];
  $volume = $_POST['volume'];
  $colour = $_POST['colour'];
  $ph = $_POST['ph'];
  $viscosity = $_POST['viscosity'];
  $liquet = $_POST['liquet'];
  $agglu = $_POST['agglu'];
  $velocity = $_POST['velocity'];
  $motility = $_POST['motility'];
  $active = $_POST['active'];
  $nonpro = $_POST['nonpro'];
  $immo = $_POST['immo'];
  $normal = $_POST['normal'];
  $abnormal = $_POST['abnormal'];
  $spermconc = $_POST['spermconc'];
  $spermno = $_POST['spermno'];
  $wbc = $_POST['wbc'];
  $comments = $_POST['comments'];
  $amx1 = $_POST['amx1'];
  $amx2 = $_POST['amx2'];
  $amx3 = $_POST['amx3'];
  $aug1 = $_POST['aug1'];
  $aug2 = $_POST['aug2'];
  $aug3 = $_POST['aug3'];
  $strep1 = $_POST['strep1'];
  $strep2 = $_POST['strep2'];
  $strep3 = $_POST['strep3'];
  $cxc1 = $_POST['cxc1'];
  $cxc2 = $_POST['cxc2'];
  $cxc3 = $_POST['cxc3'];
  $nfur1 = $_POST['nfur1'];
  $nfur2 = $_POST['nfur2'];
  $nfur3 = $_POST['nfur3'];
  $ery1 = $_POST['ery1'];
  $ery2 = $_POST['ery2'];
  $ery3 = $_POST['ery3'];
  $chlo1 = $_POST['chlo1'];
  $chlo2 = $_POST['chlo2'];
  $chlo3 = $_POST['chlo3'];
  $ctr1 = $_POST['ctr1'];
  $ctr2 = $_POST['ctr2'];
  $ctr3 = $_POST['ctr3'];
  $cxm1 = $_POST['cxm1'];
  $cxm2 = $_POST['cxm2'];
  $cxm3 = $_POST['cxm3'];
  $gm1 = $_POST['gm1'];
  $gm2 = $_POST['gm2'];
  $gm3 = $_POST['gm3'];
  $cpr1 = $_POST['cpr1'];
  $cpr2 = $_POST['cpr2'];
  $cpr3 = $_POST['cpr3'];
  $cot1 = $_POST['cot1'];
  $cot2 = $_POST['cot2'];
  $cot3 = $_POST['cot3'];
  $na1 = $_POST['na1'];
  $na2 = $_POST['na2'];
  $na3 = $_POST['na3'];
  $crx1 = $_POST['crx1'];
  $crx2 = $_POST['crx2'];
  $crx3 = $_POST['crx3'];
  $caz1 = $_POST['caz1'];
  $caz2 = $_POST['caz2'];
  $caz3 = $_POST['caz3'];
  $ofl1 = $_POST['ofl1'];
  $ofl2 = $_POST['ofl2'];
  $ofl3 = $_POST['ofl3'];
  $nin1 = $_POST['nin1'];
  $nin2 = $_POST['nin2'];
  $nin3 = $_POST['nin3'];
  $nin1 = $_POST['nin1'];
  $nin2 = $_POST['nin2'];
  $nin3 = $_POST['nin3'];
  $medlab = $_POST['medlab'];
  $meddate = $_POST['meddate'];
  $currentTime = date('Y-m-d h:i:s A', time());
  $query = mysqli_query($con, "INSERT INTO microsem (PatientID, viewID, clinician, diagnosis, material, ward, requesddate, docsign, timecollected, timereceived, timeexa, method, abstinence, volume, colour, ph, viscosity, liquet, agglu, velocity, motility, active, nonpro, immo, normal, abnormal, spermconc, spermno, wbc, comments, amx1, amx2, amx3, aug1, aug2, aug3, strep1, strep2, strep3, cxc1, cxc2, cxc3, nfur1, nfur2, nfur3, ery1, ery2, ery3, chlo1, chlo2, chlo3, ctr1, ctr2, ctr3, cxm1, cxm2, cxm3, gm1, gm2, gm3, cpr1, cpr2, cpr3, cot1, cot2, cot3, na1, na2, na3, crx1, crx2, crx3, caz1, caz2, caz3, ofl1, ofl2, ofl3, nin1, nin2, nin3, medlab, meddate)
          VALUES('" . $_GET['pid'] . "', '" . $_GET['viewid'] . "', '$clinician', '$diagnosis', '$material',  '$ward', '$requesddate', '$docsign', '$timecollected', '$timereceived', '$timeexa', '$method, '$abstinence, '$volume, '$colour, '$ph, '$viscosity, '$liquet, '$agglu, '$velocity, '$motility, '$active, '$nonpro, '$immo, '$normal, '$abnormal, '$spermconc, '$spermno, '$wbc, '$comments, '$amx1, '$amx2, '$amx3, '$aug1, '$aug2, '$aug3, '$strep1, '$strep2, '$strep3, '$cxc1, '$cxc2, '$cxc3, '$nfur1, '$nfur2, '$nfur3, '$ery1, '$ery2, '$ery3, '$chlo1, '$chlo2', '$chlo3', '$ctr1', '$ctr2', '$ctr3', '$cxm1', '$cxm2', '$cxm3', '$gm1', '$gm2', '$gm3', '$cpr1', '$cpr2', '$cpr3', '$cot1', '$cot2', '$cot3', '$na1', '$na2', '$na3', '$crx1', '$crx2', '$crx3', '$caz1', '$caz2', '$caz3', '$ofl1', '$ofl2', '$ofl3', '$nin1', '$nin2', '$nin3', '$medlab', '$meddate' )");

  if ($query) {
    $_SESSION['msg'] = "Lab Test Successfully Submitted";
    //header('location:labform.php');

  } else {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}

?>
<script language="javascript" type="text/javascript">
  function f2() {
    window.close();
  }
  ser

  function f3() {
    window.print();
  }
</script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <title>Uploaded Result</title>
  <link href="style.css" rel="stylesheet" type="text/css" />
  <link href="anuj.css" rel="stylesheet" type="text/css">

  <link href="css/layout.css" rel="stylesheet" type="text/css" />
  <link media="screen" charset="utf-8" rel="stylesheet" href="css/base.css" />
  <link media="screen" charset="utf-8" rel="stylesheet" href="css/skeleton.css" />
  <link media="screen" charset="utf-8" rel="stylesheet" href="css/child.css" />
  <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />

  <link rel="stylesheet" type="text/css" href="theme.css" />
  <link rel="stylesheet" type="text/css" href="premium.css" />
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="main.css">
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <link href="bootstrap/js/bootstrap.min.js" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <title>Toxicology</title>

  <script src="js/jquery-1.11.1.min.js" type="text/javascript"></script>
  <script type="text/javascript" language="javascript" src="js/jquery-1-8-2.js"></script>
  <script type="text/javascript" src="js/default.js"></script>
  <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
  <script type="text/javascript" src="js/jquery.carousel.js"></script>
  <script type="text/javascript" src="js/jquery.color.animation.js"></script>
  <script type="text/javascript" src="js/jquery.isotope.min.js"></script>
  <script type="text/javascript" src="js/jquery.prettyPhoto.js" charset="utf-8"></script>

</head>

<body>

  <div style="margin-left:50px;">

    <?php
    $vid = $_GET['viewid'];
    $pid = $_GET['pid'];

    //$rets = mysqli_query($con, "select * from tblmedicalhistory  where ID='" . $_GET['viewid'] . "'");
    //while ($row = mysqli_fetch_array($rets)) {

    $ret1 = mysqli_query($con, "select * FROM tblpatient where PatientID='" . $_GET['pid'] . "'");
    $rw = mysqli_fetch_array($ret1);
    if ($rw > 0) {
    ?>


      <div class="container">


        <H3 style="font-weight:bold;font-size:19px;"> Fill Lab Test for <?php echo $rw['PatientName']; ?></H3>
        <p style="color:red;"><?php echo htmlentities($_SESSION['msg']); ?>
          <?php echo htmlentities($_SESSION['msg'] = ""); ?></p>

        <br />


        <div class="filter">

          <ul id="filters" class="">
            <li><b><a href="" data-filter="#preg">Pregnancy Test</a></b></li>
            <li> <b><a href="" data-filter="#rad">Radiological Examination (xray)</a></b></li>
            <li><b><a href="" data-filter="#haema">Request-for-lab-haematology</a></b></li>
            <li><b><a href="" data-filter="#micro">Request-for-lab-micriobiolgy-bacteriology</a></b></li>
            <li><b><a href="" data-filter="#urinary">Request-for-laboratry-microbiology-urinalysis</a></b></li>
            <li><b><a href="" data-filter="#toxi">Toxicology</a></b></li>
          </ul>

          <div class="clear"></div>
        </div>
        <div class="portfolio standard one">
          <div id="isotope-container" class="portfolio-container">


            <!-- pregnancy Test Form -->
            <div class="item" id="preg">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  Request for Laboratory Services
                </h3>

                <h2>
                  PREGNANCY TEST
                </h2>


              </header>

              <body>

                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>
                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>TESTS</label><input type="text" class="form-control" placeholder="TESTS" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" class="form-control" placeholder="DATE OF REQUEST" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DR.</label><input type="text" class="form-control" placeholder="SIGNATURE OF DR." aria-label="Last name">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4>REPORT (for laboratory use only)</h4>
                    <div class="form-group">
                      <label for="exampleFormControlTextarea1">Report</label>
                      <textarea class="form-control" name="report" id="exampleFormControlTextarea1" rows="3"></textarea>
                    </div>
                  </div>
                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="pt" value="Submit">
                  </div>

                </form>

              </body>

            </div>


            <!-- Radiological Examination (xray) -->
            <div class="item" id="rad">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  Request for Laboratory Services
                </h3>

                <h2>
                  RADIOLOGICAL EXAMINATION
                </h2>


              </header>

              <body>

                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4>REPORT (for laboratory use only)</h4>
                    <h4>CLINICAL DIAGNOSIS WITH RELEVANT DETAILS FOR COMPLETION BY M.O:</h4>
                    <div class="row g-3">
                      <div class="col-4">
                        <label>PART OF THE BODY:</label>
                        <input type="text" class="form-control" placeholder="PART OF THE BODY" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>EXAMINATION REQUESTED</label> <input type="text" class="form-control" placeholder="EXAMINATION REQUESTED" aria-label="Last name">
                      </div>
                    </div>
                  </div>
                  <div class="container">
                    <h4>HAS THERE BEEN ANY OPERATION? Yes/No</h4>
                    <div class="row g-3">
                      <div class="col-4">
                        <input type="radio" name="OPERATION" value="yes">
                        <label for="YES">YES</label>
                        <input type="radio" name="OPERATION" value="no">
                        <label for="NO">NO</label><br>
                      </div>
                    </div>
                  </div>
                  <div class="container">
                    <div class="row g-3">
                      <div class="col-4">
                        <label style="font-size: small;"> X-RAY EXAMINATION? YES/NO.IF SO QUOTA X-RAY NUMBER:</label>
                        <input type="text" class="form-control" placeholder="X-RAY Number" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>M.O's NAME: </label> <input type="text" class="form-control" placeholder="M.O's NAME:" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>M.O's SIGNATURE: </label> <input type="text" class="form-control" placeholder="M.O's SIGNATURE:" aria-label="Last name">
                      </div>
                    </div>
                  </div>
                  <div class="container">
                    <h4 style="padding-top: 40px;font-weight: bolder;padding-left:2rem">WALKING CASE,CHAIR,TROLLEY,THEATRE,PORTABLE</h4>

                    <table style="width:100%;border: 1px solid black;max-width:100%;margin-top: 30px;margin-left:2rem">
                      <tr style="border: 1px solid black">
                        <th style="border: 1px solid black">""</th>
                        <th style="border: 1px solid black">""</th>

                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black">35 x 43cm</td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label></td>

                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black">35 x 35cm</td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label></td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black">30 x 40cm</td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label></td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black">24 x 30cm</td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label></td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black">18 x 24cm</td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label></td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label>Radiographer: <input name="Username" type="text" placeholder=""></label></td>
                        <td style="border: 1px solid black"><label>Checked by: <input name="Username" type="text" placeholder=""></label></td>
                      </tr>
                    </table>
                    <table style="width:100%;border: 1px solid black;max-width:100%;margin-top: 6rem;margin-left:2rem">
                      <tr style="border: 1px solid black">
                        <th style="border: 1px solid black">NOTES</th>
                        <th style="border: 1px solid black">RADIOLOGIST'S REPORT</th>

                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>

                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                      <tr style="border: 1px solid black">
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                        <td style="border: 1px solid black"><label><input name="Username" type="text" placeholder=""></label>
                        </td>
                      </tr>
                    </table>
                  </div>
                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="radiology" value="Submit">
                  </div>
                </form>
              </body>
            </div>

            <!-- request-for-lab-haematology Form -->
            <div class="item" id="haem">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  Request for Laboratory Services
                </h3>

                <h2>
                  HEAMATOLOGY TEST
                </h2>


              </header>

              <body>

                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4>REPORT (for laboratory use only)</h4>

                    <h2><u> ROUTINE INVESTIGATIONS</u></h2>

                    <div class="row g-2">

                      <div class="col -6">

                        <div class="col-9">

                          <div>
                            <input type="checkbox" name="" placeholder="">
                            <label>Full Blood Count</label>
                          </div>

                          <container class="container">

                            <label> &#8226; Haematocrit(PVC)</label><input type="text" name="" class="form-control" placeholder="(F:38-45%)  (M: 40-55%)">
                            <label> &#8226; Hamoglobin (HB)</label><input type="text" name="" class="form-control" placeholder="(F: 11 - 15g/dl) (M:13.5 - 16.5g/dl)">
                            <label> &#8226; Red Cell Count</label><input type="text" name="" class="form-control" placeholder="(F:3.8 - 5.8 x 10^12 / l) (M:4.5 - 6.5 x 10^12 / l)">
                            <label> &#8226; White Cell Count</label><input type="text" name="" class="form-control" placeholder="(2.5 - 10 x 10^9 / l)">
                            <label> WBC Differentials - Polys</label><input type="text" name="" class="form-control" placeholder="(45 - 55% )">
                            <label> WBC Differentials - Lymph</label><input type="text" name="" class="form-control" placeholder="(25 - 55% )">
                            <label> WBC Differentials - Monos</label><input type="text" name="" class="form-control" placeholder="(1 - 6% )">
                            <label> WBC Differentials - Eosin</label><input type="text" name="" class="form-control" placeholder="(1 - 8% )">
                            <label> WBC Differentials - Baso</label><input type="text" name="" class="form-control" placeholder="(0 - 1% )">
                            <label> WBC Differentials - Baso</label><input type="text" name="" class="form-control" placeholder="">
                            <label> MCV </label><input type="text" name="" class="form-control" placeholder="(76 - 96 fl)">
                            <label> MCH </label><input type="text" name="" class="form-control" placeholder="(27 - 32 pg)">
                            <label> MCHC </label><input type="text" name="" class="form-control" placeholder="(32 - 36g/dl)">
                          </container>

                        </div>
                      </div>

                      <div class="col -6">

                        <div class="col-9">


                          <br />
                          <input type="checkbox" name="" placeholder=""> <label> ESR</label><input type="text" name="" class="form-control" placeholder="(F:0-15mm/hr)  (M:0 - 7mm/hr)">
                          <input type="checkbox" name="" placeholder=""> <label> Reticulocyte Count</label><input type="text" name="" class="form-control" placeholder="(0 - 2%)">
                          <input type="checkbox" name="" placeholder=""> <label> Hb Genotype</label><input type="text" name="" class="form-control" placeholder="">
                          <input type="checkbox" name="" placeholder=""> <label> Sickling Test </label><input type="text" name="" class="form-control" placeholder="">
                          <input type="checkbox" name="" placeholder=""> <label> Blood Group</label><input type="text" name="" class="form-control" placeholder="">
                          <input type="checkbox" name="" placeholder=""> <label> Malaria Parasite</label><input type="text" name="" class="form-control" placeholder="">
                          <input type="checkbox" name="" placeholder=""> <label> HEPATITIS B</label><input type="text" name="" class="form-control" placeholder="">
                          <input type="checkbox" name="" placeholder=""> <label> HEPATITIS C</label><input type="text" name="" class="form-control" placeholder="">
                          <input type="checkbox" name="" placeholder=""> <label> HIV Screening</label><input type="text" name="" class="form-control" placeholder="">
                          <input type="checkbox" name="" placeholder=""> <label> VDRL </label><input type="text" name="" class="form-control" placeholder="">
                          <input type="checkbox" name="" placeholder=""> <label> H. Pylori</label><input type="text" name="" class="form-control" placeholder="">

                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="container">

                    <h2> WIDALAGG TEST REPORT </h2>

                    <div class="container">

                      <div class="row g-4">

                        <div class="col-6">
                          <label>S. typhi </label>
                        </div>

                        <div class="col-2">
                          <label> O </label>&#160; <input type="checkbox" name="" name="" class=" " placeholder="">
                        </div>

                        <div class="col-2">
                          <label>H</label>&#160;<input type="checkbox" name="" name="" class=" " placeholder="">
                        </div>

                        <div class="col-2">
                          <label>vi</label>&#160;<input type="checkbox" name="" name="" class=" " placeholder="">
                        </div>
                      </div>

                    </div>

                    <div class="row g-4">

                      <div class="col-6">
                        <label>S. tparatyphi A</label>
                      </div>

                      <div class="col-2">
                        <label> O </label>&#160;<input type="checkbox" name="" name="" class=" " placeholder="">
                      </div>

                      <div class="col-2">
                        <label>H</label>&#160;<input type="checkbox" name="" name="" class=" " placeholder="">
                      </div>

                      <div class="col-2">
                        <label>vi</label>&#160;<input type="checkbox" name="" name="" class=" " placeholder="">
                      </div>

                    </div>

                    <div class="row g-4">

                      <div class="col-6">
                        <label>S. tparatyphi B</label>
                      </div>

                      <div class="col-2">
                        <label> O </label>&#160;<input type="checkbox" name="" name="" class=" " placeholder="">
                      </div>

                      <div class="col-2">
                        <label>H</label>&#160;<input type="checkbox" name="" name="" class=" " placeholder="">
                      </div>

                      <div class="col-2">
                        <label>vi</label>&#160;<input type="checkbox" name="" name="" class=" " placeholder="">
                      </div>

                    </div>
                    <div class="row g-4">

                      <div class="col-6">
                        <label>S. paratyphi C</label>
                      </div>

                      <div class="col-2">
                        <label> O </label>&#160;<input type="checkbox" name="" name="" class=" " placeholder="">
                      </div>

                      <div class="col-2">
                        <label>H</label>&#160;<input type="checkbox" name="" name="" class=" " placeholder="">
                      </div>

                      <div class="col-2">
                        <label>vi</label>&#160;<input type="checkbox" name="" name="" class=" " placeholder="">
                      </div>

                    </div>
                    <br />

                    <br />
                  </div>
                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="heamatology" value="Submit">
                  </div>

                </form>

              </body>
            </div>

            <!-- request-for-lab-micriobiolgy-bacteriology Form -->
            <div class="item" id="micro">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  Request for Laboratory Services
                </h3>

                <h2>
                  MICROBIOLOGY
                  (Bacteriology)
                </h2>


              </header>

              <body>

                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4>REPORT (for laboratory use only)</h4>
                    <h4><u>HVS WET PREPARATION</u></h4>
                    <div class="input-group mb-3">
                      <span class="input-group-text">EPITHELIAL CELLS</span>
                      <input type="text" name="EPITHELIAL CELLS" class="form-control" placeholder="EPITHELIAL CELLS" aria-label="Username">
                      <span class="input-group-text">PUS CELLS</span>
                      <input type="text" name="PUS CELLS" class="form-control" placeholder="PUS CELLS" aria-label="Server">
                      <span class="input-group-text">RED BLOOD CELLS</span>
                      <input type="text" name="RED BLOOD CELLS" class="form-control" placeholder="RED BLOOD CELLS" aria-label="Server">
                    </div>
                    <div class="input-group mb-3">
                      <span class="input-group-text">BACTERIA</span>
                      <input type="text" name="BACTERIA" class="form-control" placeholder="BACTERIA" aria-label="Username">
                      <span class="input-group-text">YEAST CELLS</span>
                      <input type="text" class="form-control" name="YEAST CELLS" placeholder="YEAST CELLS" aria-label="Server">
                      <span class="input-group-text">TRICHOMONAS VEGINALIS</span>
                      <input type="text" name="TRICHOMONAS" class="form-control" placeholder="TRICHOMONAS VEGINALIS" aria-label="Server">
                    </div>
                  </div>
                  <div class="container">
                    <h4><u>GRAM STAIN</u></h4>
                    <div class="input-group mb-3">
                      <span class="input-group-text">ZIEHL NELSEN STAIN</span>
                      <input type="text" name="ZIEHL NELSEN STAIN" class="form-control" placeholder="ZIEHL NELSEN STAIN" aria-label="Server">
                    </div>
                    <div class="container">
                      <div class="input-group mb-3">
                        <span class="input-group-text">
                          <h4>CULTURE INCLUDING BIOCHEMICAL TESTS:</h4>
                        </span>
                        <input type="text" name="CULTURE" class="form-control" placeholder="CULTURE INCLUDING BIOCHEMICAL TESTS" aria-label="Server">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4><u>SENSITIVITY</u></h4>
                    <div class="container1">
                      <table style="width:10%;border: 1px solid black;max-width:10%" id="table">
                        <tr style="border: 1px solid black">
                          <th style="border: 1px solid black">AUG</th>
                          <th style="border: 1px solid black">AMX</th>
                          <th style="border: 1px solid black">PEN</th>
                          <th style="border: 1px solid black">STREP</th>
                          <th style="border: 1px solid black">COT</th>
                          <th style="border: 1px solid black">N'FUR</th>
                          <th style="border: 1px solid black">CXC</th>
                          <th style="border: 1px solid black">ERY</th>
                          <th style="border: 1px solid black">CHLO</th>
                          <th style="border: 1px solid black">TET</th>
                          <th style="border: 1px solid black">SXT</th>
                          <th style="border: 1px solid black">GM</th>
                          <th style="border: 1px solid black">OFL</th>
                          <th style="border: 1px solid black">CAZ</th>
                          <th style="border: 1px solid black">NA</th>
                          <th style="border: 1px solid black">CRX</th>
                          <th style="border: 1px solid black">CPR</th>
                          <th style="border: 1px solid black">CXM</th>
                        </tr>
                        <tr style="border: 1px solid black">
                          <td style="border: 1px solid black"><label><input name="AUG1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="AMX1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="PEN1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="STREP1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="COT1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="N'FUR1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CXC1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ERY1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CHLO1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="TET1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="SXT1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="GM1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="OFL1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CAZ1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="NA1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CRX1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CPR1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CXM1" type="text" placeholder="  "></label></td>
                        </tr>
                        <tr style="border: 1px solid black">
                          <td style="border: 1px solid black"><label><input name="AUG2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="AMX2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="PEN2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="STREP2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="COT2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="N'FUR2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CXC2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ERY2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CHLO2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="TET2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="SXT2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="GM2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="OFL2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CAZ2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="NA2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CRX2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CPR2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CXM2" type="text" placeholder="  "></label></td>
                        </tr>
                        <tr style="border: 1px solid black">
                          <td style="border: 1px solid black"><label><input name="AUG3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="AMX3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="PEN3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="STREP3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="COT3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="N'FUR3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CXC3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ERY3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CHLO3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="TET3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="SXT3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="GM3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="OFL3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CAZ3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="NA3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CRX3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CPR3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CXM3" type="text" placeholder="  "></label></td>
                        </tr>
                      </table>
                    </div>
                  </div>
                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="bacteriology" value="Submit">
                  </div>
                </form>

              </body>

            </div>

            <!--request-for-laboratory-microbiology-urine-->
            <div class="item" id="microbiologyurine">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  Request for Laboratory Services
                </h3>

                <h2>
                  MICROBIOLOGY
                  (URINE ONLY)
                </h2>
              </header>

              <body>
                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="requestdate" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4>REPORT (for laboratory use only)</h4>
                    <h4><u>MICROSCOPY:</u></h4>
                    <div class="input-group mb-3">
                      <span class="input-group-text">PUS CELLS/h.p.f</span>
                      <input type="text" class="form-control" name="puscells" placeholder="PUS CELLS/h.p.f" aria-label="Username">
                      <span class="input-group-text">Rbcs/h.p.f</span>
                      <input type="text" class="form-control" name="rbcs" placeholder="Rbcs/h.p.f" aria-label="Server">
                      <span class="input-group-text">EPITH CELLS</span>
                      <input type="text" class="form-control" name="epithcell" placeholder="EPITH CELLS" aria-label="Server">
                    </div>
                    <div class="input-group mb-3">
                      <span class="input-group-text">BACTERIA</span>
                      <input type="text" class="form-control" name="bacteria" placeholder="BACTERIA" aria-label="Username">
                      <span class="input-group-text">YEAST CELLS</span>
                      <input type="text" class="form-control" name="yeast" placeholder="YEAST CELLS" aria-label="Server">
                    </div>
                    <div class="input-group mb-3">
                      <span class="input-group-text">CASTS:</span>
                      <input type="text" class="form-control" name="casts" placeholder="casts" aria-label="Username">
                      <span class="input-group-text">AMORPHAUS DEBRIS:</span>
                      <input type="text" class="form-control" name="amorphaus" placeholder="amorphausdebris" aria-label="Server">
                    </div>
                    <div class="input-group mb-3">
                      <span class="input-group-text">CRYSTALS:</span>
                      <input type="text" class="form-control" name="crystals" placeholder="crystals" aria-label="Username">
                      <span class="input-group-text">SPERMATOZOA:</span>
                      <input type="text" class="form-control" name="spermatozoa" placeholder="spermatozoa" aria-label="Server">
                    </div>
                    <div class="input-group mb-3">
                      <span class="input-group-text">PUS CELL COUNT:</span>
                      <input type="text" class="form-control" name="puscount" placeholder="PUSCELLCOUNT" aria-label="Username">
                      <span class="input-group-text">PUS CELLS/ml:</span>
                      <input type="text" class="form-control" name="pusml" placeholder="PUSCELLS/ml" aria-label="Server">
                    </div>0
                    <div class="container">
                      <div class="input-group mb-3">
                        <span class="input-group-text">
                          <h4>CULTURE INCLUDING BIOCHEMICAL TESTS:</h4>
                        </span>
                        <input type="text" class="form-control" name="ziehlstain" placeholder="ZIEHL NELSEN STAIN" aria-label="Server">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4><u>SENSITIVITY</u></h4>
                    <div class="container1">
                      <table style="width:10%;border: 1px solid black;max-width:10%" id="table">
                        <tr style="border: 1px solid black">
                          <th style="border: 1px solid black">AUG</th>
                          <th style="border: 1px solid black">AMX</th>
                          <th style="border: 1px solid black">PEN</th>
                          <th style="border: 1px solid black">STREP</th>
                          <th style="border: 1px solid black">COT</th>
                          <th style="border: 1px solid black">N'FUR</th>
                          <th style="border: 1px solid black">CXC</th>
                          <th style="border: 1px solid black">ERY</th>
                          <th style="border: 1px solid black">CHLO</th>
                          <th style="border: 1px solid black">TET</th>
                          <th style="border: 1px solid black">SXT</th>
                          <th style="border: 1px solid black">GM</th>
                          <th style="border: 1px solid black">OFL</th>
                          <th style="border: 1px solid black">CAZ</th>
                          <th style="border: 1px solid black">NA</th>
                          <th style="border: 1px solid black">CRX</th>
                          <th style="border: 1px solid black">CPR</th>
                          <th style="border: 1px solid black">CXM</th>
                        </tr>
                        <tr style="border: 1px solid black">
                          <td style="border: 1px solid black"><label><input name="AUG1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="AMX1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="PEN1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="STREP1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="COT1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="N'FUR1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CXC1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ERY1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CHLO1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="TET1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="SXT1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="GM1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="OFL1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CAZ1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="NA1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CRX1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CPR1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CXM1" type="text" placeholder="  "></label></td>
                        </tr>
                        <tr style="border: 1px solid black">
                          <td style="border: 1px solid black"><label><input name="AUG2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="AMX2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="PEN2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="STREP2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="COT2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="N'FUR2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CXC2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ERY2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CHLO2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="TET2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="SXT2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="GM2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="OFL2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CAZ2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="NA2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CRX2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CPR2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CXM2" type="text" placeholder="  "></label></td>
                        </tr>
                        <tr style="border: 1px solid black">
                          <td style="border: 1px solid black"><label><input name="AUG3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="AMX3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="PEN3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="STREP3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="COT3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="N'FUR3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CXC3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ERY3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CHLO3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="TET3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="SXT3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="GM3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="OFL3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CAZ3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="NA3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CRX3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CPR3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="CXM3" type="text" placeholder="  "></label></td>
                        </tr>
                      </table>
                    </div>
                </form>
                <div class="container">
                  <input class="btn btn-primary" type="submit" name="microbiologyurine" value="Submit">
                </div>


              </body>

            </div>

            <!-- request-for-laboratory-urinalysis Form -->
            <div class="item" id="urinary">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  URINALYSIS
                </h3>


              </header>

              <body>

                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <h4>Requests(For Laboratory Use Only)</h4>
                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>COLOUR AND APPEARANCE</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>NITRITE</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>REACTION(Ph)</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SPECIFIC GRAVITY</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>PROTEIN</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>ASCORBIC ACID</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>REDUCING SUBSTANCES(Sugar)</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>BILLIRUBIN</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>KETONE BODIES</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>UROBILINOGEN</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>BLOOD</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>

                    </div>

                  </div>

                  <div class="container">
                    <h4>MICROSCOPY</h4>
                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>EPITHELIAL CELLS</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>PUS CELLS/HPF</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>RBCs/hpf</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>BACTERIA</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>CRYSTALS</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>CASTS</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>YEASTS CELLS</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>TRICHOMONAS VAGINALIS</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>S.HAEMATOBIUM</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>AMORPHOUS DEBRIS</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>SPERMATOZOA</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>AMORPHOUS CRYSTALS</label><input type="text" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SAMPLE COLLECTED BY</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>DATE</label><input type="date" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>TIME</label><input type="time" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>RECEIVED BY</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>DATE</label><input type="date" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>TIME</label><input type="time" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LOGGED BY</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>DATE</label><input type="date" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>TIME</label><input type="time" class="form-control" placeholder="" aria-label=" Last name ">
                      </div>

                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>MED. LAB. SCIENTIST(Signature)</label><input type="text" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                      <div class="col-4">
                        <label>MED. LAB. SCIENTIST(Date)</label><input type="date" class="form-control" placeholder="" aria-label="Last name">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="urinalysis" value="Submit">
                  </div>
                </form>

              </body>

            </div>

            <!-- toxicology Form -->
            <div class="item" id="toxi">


              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h2>
                  TOXICOLOGY TEST
                </h2>
              </header>

              <body>

                <form action="" method="POST">

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>


                  <div class="container">
                    <h2>REPORT(for laboratory use only)</h2>
                    <div class="row g-3">
                      <div class="col-4">
                        <label>MARIJUANA(THC)</label><input type="text" name="marijana" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>COCAINE(COC)</label><input type="text" name="cocaine" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>BENZODIAZEPHINE(BZO)</label><input type="text" name="benzo" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>
                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>TRICYCLIC ANTIDEPRESSANTS(TCA)</label><input type="text" name="tricy" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>METHADONE(MTD)</label><input type="text" name="metha" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OPIUM(OPIC)</label><input type="text" name="opium" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>
                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>d-AMPHETAMINE(AMP)</label><input type="text" name="amphe" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>METYLENE DIOXYMETHAMPHE.(MDMA)</label><input type="text" name="metyl" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>BARBITURATES(BAR)</label><input type="text" name="barbi" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>TRAMADOL(TML)</label><input type="text" name="trama" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHERS</label><input type="text" name="other" class="form-control" placeholder="." aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>MED. LAB. SCIENTIST</label><input type="text" name="medlab" class="form-control" placeholder="Signature" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE</label><input type="date" name="labdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">
                    <div class="form-group">
                      <label for="exampleFormControlTextarea1">COMMENT</label>
                      <textarea class="form-control" name="comment" id="exampleFormControlTextarea1" rows="3"></textarea>
                    </div>
                  </div>

                  <div class="container">
                    <div class="form-group">
                      <label for="exampleFormControlTextarea1">CONCLUSION</label>
                      <textarea class="form-control" name="conclusion" id="exampleFormControlTextarea1" rows="3"></textarea>
                    </div>
                  </div>

                  <div class="container">
                    <div class="row g-3">
                      <div class="col">
                        <label>DIREC. MED SERVICES</label><input type="text" name="sign" class="form-control" placeholder="Signature" aria-label="#">
                      </div>
                    </div>
                  </div>

                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="toxicology" value="Submit">
                  </div>

                </form>

              </body>
            </div>

            <!-- stool Test Form -->
            <div class="item" id="stooltest">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  HEALTH SERVICES
                </h2>
                <h2>
                  STOOL TEST
                </h2>
              </header>

              <body>
                <form action="" method="POST">
                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-2">

                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>


                  <div class="container">

                    <div>
                      <h4 style="margin-left: 100px; margin-top: 20px;">REPORTS(FOR LABORATORY USE ONLY)</h4>
                    </div>

                    <div class="container" style="margin-left: 100px;">
                      <dav class="row-3">
                        <dav class="col-4">
                          <input type="checkbox" id="watery" name="watery">
                          <label for="watery">watery</label>
                        </dav>
                        <dav class="col-4">
                          <input type="checkbox" id="formed" name="formed">
                          <label for="formed">formed</label>
                        </dav>
                        <dav class="col-4">
                          <input type="checkbox" id="with mucus" name="mucus">
                          <label for="with mucus">with mucus</label>
                        </dav>
                        <div class="container">
                          <dav class="row-3">
                            <dav class="col-4">
                              <input type="checkbox" id="uniformed" name="uniformed">
                              <label for="uniformed">uniformed</label>
                            </dav>
                            <dav class="col-4">
                              <input type="checkbox" id="hard formed" name="hardformed">
                              <label for="hard formed">hard formed</label>
                            </dav>
                            <dav class="col-4">
                              <input type="checkbox" id="no blood" name="noblood">
                              <label for="no blood">no blood</label>
                            </dav>
                            <div class="container">
                              <dav class="row-3">
                                <dav class="col-4">
                                  <input type="checkbox" id="soft formed" name="softformed">
                                  <label for="soft formed">soft formed</label>
                                </dav>
                                <dav class="col-4">
                                  <input type="checkbox" id="no mucus" name="nomucus">
                                  <label for="no mucus">no mucus</label>
                                </dav>
                                <dav class="col-4">
                                  <input type="checkbox" id="with blood" name="withblood">
                                  <label for="with blood">with blood</label>
                                </dav>

                            </div>
                            <div>
                              <h3>MICROSCOPY</h3>
                            </div>

                            <div class="container">

                              <div class="row g-3">
                                <div class="col-4">
                                  <label>ASCARIS LUMBRICOIDES</label><input type="text" class="form-control" name="ascaris" placeholder="ASCARIS LUMBRICOIDES" aria-label="Last name">
                                </div>
                                <div class="col-4">
                                  <label>TRICHORIS TRICHURIA</label><input type="text" class="form-control" name="trichoris" placeholder="TRICHORIS TRICHURIA" aria-label="Last name">
                                </div>
                                <div class="col-4">
                                  <label>SCHISTOSOMA MANSONI</label><input type="text" class="form-control" name="schistosoma" placeholder="SCHISTOSOMA MANSONI" aria-label="Last name">
                                </div>
                              </div>

                            </div>

                            <div class="container">

                              <div class="row g-3">
                                <div class="col-4">
                                  <label>TAPE WORM</label><input type="text" class="form-control" name="tapeworm" placeholder="TAPE WORM" aria-label="Last name">
                                </div>
                                <div class="col-4">
                                  <label>TRICHOMANAS HOMINIS</label><input type="text" class="form-control" name="trichomanas" placeholder="TRICHOMANAS HOMINIS" aria-label="Last name">
                                </div>
                                <div class="col-4">
                                  <label>E.HISTOLYTICA</label><input type="text" class="form-control" name="ehistolytica" placeholder="E.HISTOLYTICA" aria-label="Last name">
                                </div>
                              </div>

                            </div>

                            <div class="container">

                              <div class="row g-3">
                                <div class="col-4">
                                  <label>E.COLI</label><input type="text" class="form-control" name="ecoli" placeholder="E.COLI" aria-label="Last name">
                                </div>
                                <div class="col-4">
                                  <label>STRONGYLOIDES STECORALIS GLADIA LAMBIA</label><input type="text" class="form-control" name="stecoralis" placeholder="STRONGYLOIDES STECORALIS GLADIA LAMBIA" aria-label="Last name">
                                </div>
                              </div>

                            </div>

                            <H3>MISCELLANEOUS:</H3>

                            <div class="container">

                              <div class="row g-3">
                                <div class="col-4">
                                  <label>PUS CELLS</label><input type="text" class="form-control" name="puscells" placeholder="PUS CELLS" aria-label="Last name">
                                </div>
                                <div class="col-4">
                                  <label>RECS</label><input type="text" class="form-control" name="recs" placeholder="RECS" aria-label="Last name">
                                </div>
                                <div class="col-4">
                                  <label>CHARGOTLEYDAN CRYSTALS</label><input type="text" class="form-control" name="charcrystals" placeholder="CHARGOTLEYDAN CRYSTALS" aria-label="Last name">
                                </div>
                              </div>

                            </div>
                            <div>
                              <input type="checkbox" id="no ova or protozoa" name="ovaprotozoa">
                              <label for="no ova or protozoa">no ova or protozoa</label>
                            </div>

                            <div class="container">

                              <div class="row g-3">
                                <div class="col-4">
                                  <label>OTHER TESTS</label><input type="text" class="form-control" name="othertest" placeholder="OTHER TEST" aria-label="Last name">
                                </div>
                                <div class="col-4">
                                  <label>OCCULT BLOOD</label><input type="text" class="form-control" name="occultblood" placeholder="OCCULT BIOOD" aria-label="Last name">
                                </div>
                              </div>

                            </div>

                            <div class="container">

                                <div class="row g-3">

                                    <div class="col-4">
                                        <label>MED. LAB. SCIENTIST</label><input type="text" name="medlab" class="form-control" placeholder="Signature" aria-label="#">
                                    </div>

                                    <div class="col-4">
                                        <label>DATE</label><input type="date" name="labdate" class="form-control" placeholder="." aria-label="#">
                                    </div>
                                    
                                </div>

                            </div>

                            <!-- <div class="container">

                                <div class="row g-3">
                                    <div class="col">
                                        <label>DIREC. MED SERVICES</label><input type="text" name="sign" class="form-control" placeholder="Signature" aria-label="#">
                                    </div>
                                </div>
                            </div> -->


                            <div class="container">
                              <input class="btn btn-primary" type="submit" name="stooltest" value="Submit">
                            </div>
                </form>
              </body>

            </div>

            <!-- clinical-chemistry Test Form -->
            <div class="item" id="clichem">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  CLINICAL CHEMISTRY TEST
                </h3>
              </header>


              <body>

                <form action="" method="POST">>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>HOSP. NO.</label><input type="text" name="hospitalno" value="  " class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PATH NO.</label><input type="text" name="patientno" value=" " class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value=" " class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SURNAME</label><input type="text" name="surname" value=" " class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="othernames" value=" " class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>AGE</label><input type="text" name="age" value=" " class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>SEX</label><input type="text" name="sex" value=" " class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>STAFF/STUDENT</label><input type="text" name="role" value=" " class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>FACULTY/DEPT.</label><input type="text" name="faculty" value=" " class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>LEVEL</label><input type="text" name="level" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATRIC NO.</label><input type="text" name="matricno" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE</label><input type="text" name="phone" value="<?php echo $rw['PatientContno']; ?>" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                      </div>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>WARD OPD</label><input type="text" name="ward" class="form-control" placeholder="" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                      </div>
                    </div>

                  </div>


                  <!-- ---- REORT (for Laboratory use only section-- -->

                  <div class="container">

                    <h5> <u> REPORT (for Laboratory use only) </u> </h5>

                    <div class="row ">

                      <div class="col g-5">

                        <!-- <br/>  -->
                        <label><b> Electrolytes/RenalFunction: </b></label>
                        <br /><br />

                        <label> <input type="checkbox" name="bicarbonbox" placeholder="" aria-label="#"> Bicarbonate </label><input type="text" name="bicarbon" class="form-control" placeholder=" 21 - 28 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="chloridebox" placeholder="" aria-label="#"> Chloride </label><input type="text" name="chloride" class="form-control" placeholder=" 98 - 108 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="sodiumbox" placeholder="" aria-label="#"> Sodium </label><input type="text" name="sodium" class="form-control" placeholder=" 135 - 145 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="potasbox" placeholder="" aria-label="#"> Potassium </label><input type="text" name="potas" class="form-control" placeholder=" 3.5 - 5.5 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="calciumbox" placeholder="" aria-label="#"> Calcium </label><input type="text" name="calcium" class="form-control" placeholder=" 2.2 - 2.9 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="phosphbox" placeholder="" aria-label="#"> Phosphorus </label><input type="text" name="phosph" class="form-control" placeholder=" 0.8 - 1.5 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="ureabox" placeholder="" aria-label="#"> Urea </label><input type="text" name=" urea" class="form-control" placeholder=" 1.7 - 8.3 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="serumbox" placeholder="" aria-label="#"> Serum Creatinine </label><input type="text" name="serum" class="form-control" placeholder=" 44.3 - 133.1 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="creatbox" placeholder="" aria-label="#"> Creatinine Clearance </label><input type="text" name="creat" class="form-control" placeholder=" 70 - 125 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="uricbox" placeholder="" aria-label="#"> Uric Acid </label><input type="text" name="uric" class="form-control" placeholder=" 142.8 - 416.5 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="totprobox" placeholder="" aria-label="#"> Total Protein </label><input type="text" name="totpro " class="form-control" placeholder=" 66 - 87 g/L" aria-label="#">
                        <label> <input type="checkbox" name="albuminbox" placeholder="" aria-label="#"> Albumin </label><input type="text" name=" albumin" class="form-control" placeholder=" 39 - 49 g/L" aria-label="#">

                        <container>

                          <div>
                            <br />
                            <label> <b> Liver Function Tests </b> </label>
                            <br /> <br />
                          </div>

                        </container>

                        <label> <input type="checkbox" placeholder="" name="aspbox" aria-label="#"> Aspartate Transaminase </label><input type="text" name="asp" class="form-control" placeholder=" 0 - 37 U/L" aria-label="#">
                        <label> <input type="checkbox" placeholder="" name="alaninebox" aria-label="#"> Alanine Transaminase </label><input type="text" name="alanine" class="form-control" placeholder=" 0 - 41 U/L" aria-label="#">
                        <label> <input type="checkbox" placeholder="" name="alkabox" aria-label="#"> Alkaline Phosphatase</label><input type="text" name="alka" class="form-control" placeholder=" 35 - 130 U/L" aria-label="#">
                        <label> <input type="checkbox" placeholder="" name="tbillibox" aria-label="#"> Total Bilirubin</label><input type="text" name="tbilli" class="form-control" placeholder=" < 17.1 umol/L" aria-label="#">
                        <label> <input type="checkbox" placeholder="" name="dbillibox" aria-label="#"> Direct Bilirubin</label><input type="text" name="dbilli" class="form-control" placeholder=" < 17.1 umol/L" aria-label="#">


                      </div>

                      <div class="col g-5">

                        <container>

                          <div>
                            <br />
                            <label> <b> Diabetes Screening : </b> </label>
                            <br /> <br />
                          </div>

                        </container>

                        <label> <input type="checkbox" placeholder="" name="glucosebox" aria-label="#"> Glucose (Fasting) </label><input type="text" class="form-control" name="glucose" placeholder="3.6 - 6.4 mmol/L" aria-label="#">
                        <label> <input type="checkbox" placeholder="" name="2hppbox" aria-label="#"> 2hpp </label><input type="text" class="form-control" name="2hpp" placeholder="< 9.45 mmol/L" aria-label="#">
                        <label> <input type="checkbox" placeholder="" name="rbsbox" aria-label="#"> RBS</label><input type="text" class="form-control" name="rbs" placeholder=" 6.9 mmol/L" aria-label="#">
                        <label> <input type="checkbox" placeholder="" name="hba1box" aria-label="#"> HBA,C(1)</label><input type="text" class="form-control" name="hba1" placeholder=" < 7%" aria-label="#">
                        <label> <input type="checkbox" placeholder="" name="hba2box" aria-label="#"> HBA,C(2)</label><input type="text" class="form-control" name="hba2" placeholder=" < 53 mmol/L" aria-label="#">
                        <label> <input type="checkbox" placeholder="" name="gtoltextbox" aria-label="#"> Glucose Tolerance Test </label><input type="text" name="gtoltext" class="form-control" placeholder="" aria-label="#">

                        <br />
                        <label><b> Lipids: </b></label>
                        <br /><br />

                        <label> <input type="checkbox" name="Totalcholbox" placeholder="" aria-label="#"> Total Cholesterol </label><input type="text" class="form-control" name="totalchol" placeholder="<5.2 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="hdlbox" placeholder="" aria-label="#"> HDL Cholesterol </label><input type="text" class="form-control" name="hdl" placeholder="1.10 - 1.68 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="ldlbox" placeholder="" aria-label="#"> LDL Cholesterol </label><input type="text" class="form-control" name="ldl" placeholder="2.59 - 3.34 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="vldlbox" placeholder="" aria-label="#"> VLDL Cholesterol </label><input type="text" class="form-control" name="vldl" placeholder=" " aria-label="#">
                        <label> <input type="checkbox" name="trigbox" placeholder="" aria-label="#"> Triglyceride</label><input type="text" class="form-control" name="trig" placeholder="<2.3 mmol/L" aria-label="#">
                        <label> <input type="checkbox" name="psabox" placeholder="" aria-label="#"> P. S. A Total </label><input type="text" class="form-control" name="psa" placeholder="<4ng/ml" aria-label="#">
                        <label> <input type="checkbox" name="Othersbox" placeholder="" aria-label="#"> Other Tests </label><input type="text" class="form-control" name="others" placeholder="" aria-label="#">


                        <div>
                          <br />
                          <label> <b> Comments:</b> </label>
                          <br />
                          <textarea class="form-control" name="comments" placeholder="" aria-label="#"></textarea>
                          <br />
                        </div>

                      </div>

                    </div>

                    <div class="row">

                      <div class="col g-5">

                        <br />
                        <label>MED. LAB. SCIENTIST(Signature)</label><input type="text" name="sign" class="form-control" placeholder="" aria-label="Last name">
                        <br />

                      </div>

                      <div class="col g-5">

                        <br />
                        <label>MED. LAB. SCIENTIST(Date)</label><input type="date" name="meddate" class="form-control" placeholder="" aria-label="Last name">
                        <br />

                      </div>

                    </div>

                  </div>
                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="clichem" value="Submit">
                  </div>
                </form>

              </body>

            </div>
            <!-- microbiology seminal analysis Form -->
            <div class="item" id="microsem">
              <header>
                <h1>
                  UNIVERSITY OF LAGOS
                </h1>
                <h2>
                  MEDICAL CENTRE
                </h2>

                <h3>
                  Request for Laboratory Services
                </h3>

                <h2>
                  MICROBIOLOGY
                  (SEMINAL ANALYSIS)
                </h2>
              </header>

              <body>

                <form action="" method="POST">

                  <div class="row g-3">
                    <div class="col-4">
                      <label>HOSP. NO.</label><input type="text" name="hospitalno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="" aria-label="#">
                    </div>
                    <div class="col-4">
                      <label>PATH NO.</label><input type="text" name="patientno" value="<?php echo $rw['PatientID']; ?>" class="form-control" placeholder="." aria-label="#">
                    </div>
                    <div class="col-4">
                      <label>NHIS/TSHIP NO.</label><input type="text" name="nhisno" value="<?php echo $rw['NHIS_No']; ?>" class="form-control" placeholder="" aria-label="#">
                    </div>
                  </div>

            </div>

            <div class="container">

              <div class="row g-3">
                <div class="col-4">
                  <label>SURNAME</label><input type="text" name="surname" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="" aria-label="#">
                </div>
                <div class="col-4">
                  <label>OTHER NAMES</label><input type="text" name="othernames" value="<?php echo $rw['PatientName']; ?>" class="form-control" placeholder="." aria-label="#">
                </div>
                <div class="col-4">
                  <label>AGE</label><input type="text" name="age" value="<?php echo $rw['PatientAge']; ?>" class="form-control" placeholder="" aria-label="#">
                </div>
              </div>

            </div>

            <div class="container">

              <div class="row g-3">
                <div class="col-4">
                  <label>SEX</label><input type="text" name="sex" value="<?php echo $rw['PatientGender']; ?>" class="form-control" placeholder="" aria-label="#">
                </div>
                <div class="col-4">
                  <label>STAFF/STUDENT</label><input type="text" name="role" value="<?php echo $rw['Patient_Type']; ?>" class="form-control" placeholder="." aria-label="#">
                </div>
                <div class="col-4">
                  <label>FACULTY/DEPT.</label><input type="text" name="faculty" value="<?php echo $rw['employer']; ?>" class="form-control" placeholder="" aria-label="#">
                </div>
              </div>

            </div>



            <div class="container">

              <div class="row g-3">
                <div class="col-4">
                  <label>NEXT OF KIN(SURNAME)</label><input type="text" name="kin" class="form-control" placeholder="" aria-label="#">
                </div>
                <div class="col-4">
                  <label>OTHER NAMES</label><input type="text" name="kinname" class="form-control" placeholder="." aria-label="#">
                </div>
                <div class="col-4">
                  <label>PHONE NO</label><input type="text" name="kinphone" class="form-control" placeholder="" aria-label="#">
                </div>
              </div>

            </div>

            <div class="container">

              <div class="row g-3">
                <div class="col-4">
                  <label>CLINICIAN</label><input type="text" name="clinician" class="form-control" placeholder="" aria-label="#">
                </div>
                <div class="col-4">
                  <label>CLINICIAN SUMMARY AND DIAGNOSIS</label><input type="text" name="diagnosis" class="form-control" placeholder="." aria-label="#">
                </div>
                <div class="col-4">
                  <label>MATERIAL</label><input type="text" name="material" class="form-control" placeholder="Urine" aria-label="#">
                </div>
              </div>

            </div>

            <div class="container">

              <div class="row g-3">
                <div class="col-4">
                  <label>TESTS</label><input type="text" name="tests" class="form-control" placeholder="" aria-label="#">
                </div>
                <div class="col-4">
                  <label>DATE OF REQUEST</label><input type="date" name="requestdate" class="form-control" placeholder="." aria-label="#">
                </div>
                <div class="col-4">
                  <label>SIGNATURE OF DOCTOR</label><input type="text" name="docsign" class="form-control" placeholder="" aria-label="#">
                </div>
              </div>

            </div>

            <div class="container">

              <h4>REPORT (for laboratory use only)</h4>

              <div class="container">

                <div class="row">
                  <div class="col">
                    <b> PARAMETER </b>
                  </div>
                  <div class="col-6">
                    <b> RESULT </b>
                  </div>
                  <div class="col">
                    <b> NORMAL RANGE </b>
                  </div>
                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    Time Collected
                  </div>

                  <div class="col-6">
                    <input type="text" name="timecollected" class="form-control" placeholder="" aria-label="#">
                  </div>
                  <div class="col">

                  </div>

                </div>


                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    Time Received
                  </div>

                  <div class="col-6">
                    <input type="text" name="timereceived" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">

                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    Time Examined
                  </div>

                  <div class="col-6">
                    <input type="text" name="timeexa" class="form-control" placeholder="" aria-label="#">
                  </div>
                  <div class="col">

                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    Method
                  </div>

                  <div class="col-6">
                    <input type="text" name="method" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">

                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    Abstinence
                  </div>

                  <div class="col-6">
                    <input type="text" name="abstinence" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">
                    2-7days
                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    Volume
                  </div>

                  <div class="col-6">
                    <input type="text" name="volume" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">
                    => 1.5mls
                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    Colour
                  </div>

                  <div class="col-6">
                    <input type="text" name="colour" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">

                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    PH
                  </div>

                  <div class="col-6">
                    <input type="text" name="ph" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">
                    7.2 - 7.8
                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    Viscosity
                  </div>

                  <div class="col-6">
                    <input type="text" name="viscosity" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">
                    Normal/+
                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    Liquetaction
                  </div>

                  <div class="col-6">
                    <input type="text" name="liquet" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">
                    10-60mins
                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    Agglutination
                  </div>

                  <div class="col-6">
                    <input type="text" name="agglu" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">
                    Absent/+
                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    velocity
                  </div>

                  <div class="col-6">
                    <input type="text" name="velocity" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">
                    Fair/Good/Excellent
                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    %Motility
                  </div>

                  <div class="col-6">
                    <input type="text" name="motility" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">
                    =>40%
                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    %Active Progression
                  </div>

                  <div class="col-6">
                    <input type="text" name="active" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">

                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    %Non Progressive
                  </div>

                  <div class="col-6">
                    <input type="text" name="nonpro" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">

                  </div>

                </div>

                <div class="row" style="margin-bottom:10px;">

                  <div class="col">
                    %Immolile
                  </div>

                  <div class="col-6">
                    <input type="text" name="immo" class="form-control" placeholder="" aria-label="#">
                  </div>

                  <div class="col">
                    =< 60% </div>

                  </div>



                  <div class="row" style="margin-bottom:10px;">

                    <div class="col">
                      %Normal cells
                    </div>

                    <div class="col-6">
                      <input type="text" name="normal" class="form-control" placeholder="" aria-label="#">
                    </div>

                    <div class="col">
                      =>4%
                    </div>

                  </div>

                  <div class="row" style="margin-bottom:10px;">

                    <div class="col">
                      %Abnormal cells
                    </div>

                    <div class="col-6">
                      <input type="text" name="abnormal" class="form-control" placeholder="" aria-label="#">
                    </div>

                    <div class="col">
                      <=96% </div>

                    </div>

                    <div class="row" style="margin-bottom:10px;">

                      <div class="col">
                        Sperm Concentration
                      </div>

                      <div class="col-6">
                        <input type="text" name="spermconc" class="form-control" placeholder="" aria-label="#">
                      </div>

                      <div class="col">
                        >= 15.0 x 10 <sup>5</sup>/ml
                      </div>

                    </div>

                    <div class="row" style="margin-bottom:10px;">

                      <div class="col">
                        Sperm Numbers
                      </div>

                      <div class="col-6">
                        <input type="text" name="spermno" class="form-control" placeholder="" aria-label="#">
                      </div>

                      <div class="col">
                        > 39.0 x 10 <sup>5</sup>/ml
                      </div>

                    </div>

                    <div class="row" style="margin-bottom:10px;">

                      <div class="col">
                        Wbc Count
                      </div>

                      <div class="col-6">
                        <input type="text" name="wbc" class="form-control" placeholder="" aria-label="#">
                      </div>

                      <div class="col">
                        <= 1.0 x 10 <sup>5</sup>/ml
                      </div>

                    </div>

                    <div class="row" style="margin-bottom:10px;">

                      <div class="col">
                        Comment
                      </div>

                      <div class="col-6">
                        <input type="text" name="comments" class="form-control" placeholder="" aria-label="#">
                      </div>

                      <div class="col">

                      </div>

                    </div>


                  </div>

                  <br />

                  <b>
                    <h3> CULTURE INCLUDING BIOCHEMICAL TESTS </h3>
                  </b>

                  <div class="container">

                    <h4><u>Sensitivity</u></h4>

                    <div class="container1">
                      <table style="width:10%;border: 1px solid black;max-width:10%" id="table">
                        <tr style="border: 1px solid black">
                          <th style="border: 1px solid black">AMX</th>
                          <th style="border: 1px solid black">AUG</th>
                          <th style="border: 1px solid black">Strep</th>
                          <th style="border: 1px solid black">CXC</th>
                          <th style="border: 1px solid black">N'FUR</th>
                          <th style="border: 1px solid black">Ery</th>
                          <th style="border: 1px solid black">Chlo</th>
                          <th style="border: 1px solid black">CTR</th>
                          <th style="border: 1px solid black">CXM</th>
                          <th style="border: 1px solid black">GM</th>
                          <th style="border: 1px solid black">CPR</th>
                          <th style="border: 1px solid black">COT</th>
                          <th style="border: 1px solid black">NA</th>
                          <th style="border: 1px solid black">CRX</th>
                          <th style="border: 1px solid black">CAZ</th>
                          <th style="border: 1px solid black">OFL</th>
                          <th style="border: 1px solid black"> </th>
                          <th style="border: 1px solid black"> </th>
                        </tr>
                        <tr style="border: 1px solid black">

                          <td style="border: 1px solid black"><label><input name="amx1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="aug1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="strep1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="cxc1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="nfur1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ery1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="chlo1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ctr1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="cxm1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="gm1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="cpr1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="cot1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="na1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="crx1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="caz1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ofl1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="nin1" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="nin1" type="text" placeholder="  "></label></td>

                        </tr>

                        <tr style="border: 1px solid black">
                          <td style="border: 1px solid black"><label><input name="amx2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="aug2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="strep2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="cxc2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="nfur2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ery2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="chlo2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ctr2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="cxm2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="gm2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="cpr2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="cot2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="na2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="crx2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="caz2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ofl2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="nin2" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="nin2" type="text" placeholder="  "></label></td>
                        </tr>
                        <tr style="border: 1px solid black">
                          <td style="border: 1px solid black"><label><input name="amx3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="aug3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="strep3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="cxc3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="nfur3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ery3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="chlo3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ctr3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="cxm3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="gm3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="cpr3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="cot3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="na3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="crx3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="caz3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="ofl3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="nin3" type="text" placeholder="  "></label></td>
                          <td style="border: 1px solid black"><label><input name="nin3" type="text" placeholder="  "></label></td>
                        </tr>
                      </table>
                    </div>

                  </div>

                  <div class="container">

                    <div class="row g-3">
                      <div class="col-4">
                        <label>MED. LAB. SCIENTIST</label><input type="text" name="medlab" class="form-control" placeholder="Signature" aria-label="#">
                      </div>
                      <div class="col-4">
                        <label>DATE</label><input type="date" name="meddate" class="form-control" placeholder="." aria-label="#">
                      </div>
                    </div>

                  </div>
                  <div class="container">
                    <input class="btn btn-primary" type="submit" name="microsem" value="Submit">
                  </div>
                  </form>

            
              </body>
        </div>
</div>
</div>
</div>
</div>
</div>

<tr>
  <td colspan="2">
    <input name="Submit2" type="submit" class="txtbox4" value="Close this window " onClick="return f2();" style="cursor: pointer;" />
  </td>
</tr>
<?php } ?>
</div>

<script type="text/javascript">
  $(document).ready(function() {
    $('.slidewrap2').carousel({
      slider: '.slider',
      slide: '.slide',
      slideHed: '.slidehed',
      nextSlide: '.next',
      prevSlide: '.prev',
      addPagination: false,
      addNav: false
    });
  });
  $(window).load(function() {
    $("a[class^='prettyPhoto']").prettyPhoto({
      social_tools: ''
    });
    // cache container
    var $container = $('#isotope-container');
    // initialize isotope
    $container.isotope({
      animationOptions: {
        duration: 750,
        easing: 'linear',
        queue: false
      },
      layoutMode: 'fitRows'
    });
    // filter items when filter link is clicked
    $('#filters a').click(function() {
      $("#filters a.active").removeClass('active');
      $(this).addClass('active');
      var selector = $(this).attr('data-filter');
      $container.isotope({
        filter: selector
      });
      return false;
    });
  });
</script>

</body>

</html>