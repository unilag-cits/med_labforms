-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 16, 2021 at 11:13 AM
-- Server version: 8.0.23-0ubuntu0.20.04.1
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `urinalysis`
--

-- --------------------------------------------------------

--
-- Table structure for table `stooltest`
--

CREATE TABLE `stooltest` (
  `id` int NOT NULL,
  `PatientID` varchar(250) NOT NULL,
  `viewID` varchar(250) NOT NULL,
  `clinician` varchar(250) NOT NULL,
  `diagnosis` varchar(250) NOT NULL,
  `material` varchar(250) NOT NULL,
  `watery` int NOT NULL,
  `formed` int NOT NULL,
  `mucus` int NOT NULL,
  `uniformed` int NOT NULL,
  `hardformed` int NOT NULL,
  `noblood` int NOT NULL,
  `softformed` int NOT NULL,
  `nomucus` int NOT NULL,
  `withblood` int NOT NULL,
  `ascaris` varchar(250) NOT NULL,
  `trichoris` varchar(250) NOT NULL,
  `schistomanas` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `tapeworm` varchar(250) NOT NULL,
  `trichomanas` varchar(250) NOT NULL,
  `ehistolytica` varchar(250) NOT NULL,
  `ecoli` varchar(250) NOT NULL,
  `stecoralis` varchar(250) NOT NULL,
  `puscells` varchar(250) NOT NULL,
  `recs` varchar(250) NOT NULL,
  `charcrystals` varchar(250) NOT NULL,
  `ovaprotozoa` int NOT NULL,
  `othertest` int NOT NULL,
  `occultblood` int NOT NULL,
  `doctorsign` varchar(250) NOT NULL,
  `labsign` varchar(250) NOT NULL,
  `requestDate` date NOT NULL,
  `resultDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stooltest`
--
ALTER TABLE `stooltest`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stooltest`
--
ALTER TABLE `stooltest`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
