-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2021 at 10:07 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `toxicology`
--

CREATE TABLE `toxicology` (
  `id` int(11) NOT NULL,
  `PatientID` int(9) NOT NULL,
  `viewID` int(11) NOT NULL,
  `clinician` varchar(250) NOT NULL,
  `diagnosis` varchar(250) NOT NULL,
  `material` varchar(250) NOT NULL,
  `marijana` varchar(250) NOT NULL,
  `cocaine` varchar(250) NOT NULL,
  `benzodiazephine` varchar(250) NOT NULL,
  `tricyclic_antidepressants` varchar(250) NOT NULL,
  `methadone` varchar(250) NOT NULL,
  `opium` varchar(250) NOT NULL,
  `amphetamine` varchar(250) NOT NULL,
  `metylene_dioxymethamphe` varchar(250) NOT NULL,
  `barbiturates` varchar(250) NOT NULL,
  `tramadol` varchar(250) NOT NULL,
  `others` varchar(250) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `conclusion` varchar(256) NOT NULL,
  `doctorsign` varchar(250) NOT NULL,
  `labsign` varchar(250) NOT NULL,
  `requestDate` date NOT NULL,
  `resultDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `toxicology`
--

INSERT INTO `toxicology` (`id`, `PatientID`, `viewID`, `clinician`, `diagnosis`, `material`, `marijana`, `cocaine`, `benzodiazephine`, `tricyclic_antidepressants`, `methadone`, `opium`, `amphetamine`, `metylene_dioxymethamphe`, `barbiturates`, `tramadol`, `others`, `comment`, `conclusion`, `doctorsign`, `labsign`, `requestDate`, `resultDate`) VALUES
(2, 1, 0, '', '', '', 'ffgg', 'hkjk', 'jkk', 'kdsh', 'jds', 'usdl', 'klds', 'lkpods', 'idk', 'udkj', 'sskj', 'ghj', 'gghl', 'COPIER', '', '2021-06-08', '2021-06-09'),
(3, 1, 0, '', '', 'hhgjhj', 'ffgg', 'hkjk', 'jkk', 'kdsh', 'jds', 'pqr', 'klds', 'vwx', 'yza', 'udkj', 'sskj', 'hjl;', 'kjjkshl', 'COPIER', '', '2021-06-09', '2021-06-08'),
(4, 1, 6, '', '', '', 'ABC', 'DEF', 'GHI', 'JKL', 'MNO', 'pqr', 'stu', 'VDU', 'XYZ', 'udkj', 'sskj', 'Now commented', 'Now concluded', 'COPIER', '', '2021-06-07', '2021-06-09'),
(5, 1, 6, '', 'hlxcb', 'hsa', 'ABC', 'DEF', 'GHI', 'JKL', 'MNO', 'pqr', 'stu', 'VDU', 'XYZ', 'udkj', 'sskj', 'Now commented', 'Now concluded', 'COPIER', '', '2021-06-02', '2021-06-09'),
(6, 1, 6, 'hjxk', 'hlxcb', 'Urine', 'abc', 'def', 'ghi', 'jkl', 'mno', 'PQR', 'STU', 'VDU', 'XYZ', 'udkj', 'sskj', '  Now commented now', '  Now concluded Now', 'COPIER', 'Salis', '2021-06-09', '2021-06-09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `toxicology`
--
ALTER TABLE `toxicology`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `toxicology`
--
ALTER TABLE `toxicology`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
