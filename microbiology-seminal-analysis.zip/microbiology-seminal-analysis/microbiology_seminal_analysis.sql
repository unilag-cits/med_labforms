-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 27, 2021 at 04:21 PM
-- Server version: 8.0.23-0ubuntu0.20.04.1
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `med_laboratory`
--

-- --------------------------------------------------------

--
-- Table structure for table `microbiology_seminal_analysis`
--

CREATE TABLE `microbiology_seminal_analysis` (
  `timecollected` date NOT NULL,
  `timereceived` date NOT NULL,
  `timeexamined` date NOT NULL,
  `method` varchar(50) NOT NULL,
  `abstinence` varchar(50) NOT NULL,
  `volume` varchar(50) NOT NULL,
  `colour` varchar(50) NOT NULL,
  `ph` varchar(50) NOT NULL,
  `viscosity` varchar(50) NOT NULL,
  `liquefaction` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `agglut` varchar(50) NOT NULL,
  `velocity` varchar(50) NOT NULL,
  `motility` varchar(50) NOT NULL,
  `aprogression` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `nonprogression` varchar(50) NOT NULL,
  `immotile` varchar(50) NOT NULL,
  `normalcells` varchar(50) NOT NULL,
  `abnormalcells` varchar(50) NOT NULL,
  `spermconc` varchar(50) NOT NULL,
  `spermnum` varchar(50) NOT NULL,
  `wbccount` varchar(50) NOT NULL,
  `comment` longtext NOT NULL,
  `amx1` varchar(10) NOT NULL,
  `amx2` varchar(10) NOT NULL,
  `amx3` varchar(10) NOT NULL,
  `aug1` varchar(10) NOT NULL,
  `aug2` varchar(10) NOT NULL,
  `aug3` varchar(10) NOT NULL,
  `strep1` varchar(10) NOT NULL,
  `strep2` varchar(10) NOT NULL,
  `strep3` varchar(10) NOT NULL,
  `cxc1` varchar(10) NOT NULL,
  `cxc2` varchar(10) NOT NULL,
  `cxc3` varchar(10) NOT NULL,
  `nfur1` varchar(10) NOT NULL,
  `nfur2` varchar(10) NOT NULL,
  `nfur3` varchar(10) NOT NULL,
  `ery1` varchar(10) NOT NULL,
  `ery2` varchar(10) NOT NULL,
  `ery3` varchar(10) NOT NULL,
  `chlo1` varchar(10) NOT NULL,
  `chlo2` varchar(10) NOT NULL,
  `chlo3` varchar(10) NOT NULL,
  `ctr1` varchar(10) NOT NULL,
  `ctr2` varchar(10) NOT NULL,
  `ctr3` varchar(10) NOT NULL,
  `cxm1` varchar(10) NOT NULL,
  `cxm2` varchar(10) NOT NULL,
  `cxm3` varchar(10) NOT NULL,
  `gm1` varchar(10) NOT NULL,
  `gm2` varchar(10) NOT NULL,
  `gm3` varchar(10) NOT NULL,
  `cpr1` varchar(10) NOT NULL,
  `cpr2` varchar(10) NOT NULL,
  `cpr3` varchar(10) NOT NULL,
  `cot1` varchar(10) NOT NULL,
  `cot2` varchar(10) NOT NULL,
  `cot3` varchar(10) NOT NULL,
  `na1` varchar(10) NOT NULL,
  `na2` varchar(10) NOT NULL,
  `na3` varchar(10) NOT NULL,
  `crx1` varchar(10) NOT NULL,
  `crx2` varchar(10) NOT NULL,
  `crx3` varchar(10) NOT NULL,
  `caz1` varchar(10) NOT NULL,
  `caz2` varchar(10) NOT NULL,
  `caz3` varchar(10) NOT NULL,
  `ofl1` varchar(10) NOT NULL,
  `ofl2` varchar(10) NOT NULL,
  `ofl3` varchar(10) NOT NULL,
  `doctorsign` varchar(10) NOT NULL,
  `labsign` varchar(10) NOT NULL,
  `requestDate` date NOT NULL,
  `resultDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
