-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2021 at 12:54 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bacteriology`
--

-- --------------------------------------------------------

--
-- Table structure for table `bacteriology`
--

CREATE TABLE `bacteriology` (
  `id` int(11) NOT NULL,
  `PatientID` int(9) NOT NULL,
  `viewID` int(11) NOT NULL,
  `clinician` varchar(250) NOT NULL,
  `diagnosis` varchar(250) NOT NULL,
  `material` varchar(250) NOT NULL,
  `ward` varchar(250) NOT NULL,
  `requestdate` date NOT NULL,
  `docsign` varchar(250) NOT NULL,
  `EPITHELIALCELLS` varchar(250) NOT NULL,
  `PUSCELLS` varchar(250) NOT NULL,
  `RedBloodCells` varchar(70) NOT NULL,
  `BACTERIA` varchar(250) NOT NULL,
  `YeastCells` varchar(250) NOT NULL,
  `TRICHOMONAS` varchar(250) NOT NULL,
  `ZiehlNelsenStain` varchar(250) NOT NULL,
  `CULTURE` varchar(250) NOT NULL,
  `AUG1` varchar(250) NOT NULL,
  `AUG2` varchar(250) NOT NULL,
  `AUG3` varchar(250) NOT NULL,
  `AMX1` varchar(250) NOT NULL,
  `AMX2` varchar(250) NOT NULL,
  `AMX3` varchar(250) NOT NULL,
  `PEN1` varchar(250) NOT NULL,
  `PEN2` varchar(250) NOT NULL,
  `PEN3` varchar(250) NOT NULL,
  `STREP1` varchar(250) NOT NULL,
  `STREP2` varchar(250) NOT NULL,
  `STREP3` varchar(250) NOT NULL,
  `COT1` varchar(250) NOT NULL,
  `COT2` varchar(250) NOT NULL,
  `COT3` varchar(250) NOT NULL,
  `NFUR1` varchar(250) NOT NULL,
  `NFUR2` varchar(250) NOT NULL,
  `NFUR3` varchar(250) NOT NULL,
  `CXC1` varchar(250) NOT NULL,
  `CXC2` varchar(250) NOT NULL,
  `CXC3` varchar(250) NOT NULL,
  `ERY1` varchar(250) NOT NULL,
  `ERY2` varchar(250) NOT NULL,
  `ERY3` varchar(250) NOT NULL,
  `CHLO1` varchar(250) NOT NULL,
  `CHLO2` varchar(250) NOT NULL,
  `CHLO3` varchar(250) NOT NULL,
  `TET1` varchar(250) NOT NULL,
  `TET2` varchar(250) NOT NULL,
  `TET3` varchar(250) NOT NULL,
  `SXT1` varchar(250) NOT NULL,
  `SXT2` varchar(250) NOT NULL,
  `SXT3` varchar(250) NOT NULL,
  `GM1` varchar(250) NOT NULL,
  `GM2` varchar(250) NOT NULL,
  `GM3` varchar(250) NOT NULL,
  `OFL1` varchar(250) NOT NULL,
  `OFL2` varchar(250) NOT NULL,
  `OFL3` varchar(250) NOT NULL,
  `CAZ1` varchar(250) NOT NULL,
  `CAZ2` varchar(250) NOT NULL,
  `CAZ3` varchar(250) NOT NULL,
  `NA1` varchar(250) NOT NULL,
  `NA2` varchar(250) NOT NULL,
  `NA3` varchar(250) NOT NULL,
  `CRX1` varchar(250) NOT NULL,
  `CRX2` varchar(250) NOT NULL,
  `CRX3` varchar(250) NOT NULL,
  `CPR1` varchar(250) NOT NULL,
  `CPR2` varchar(250) NOT NULL,
  `CPR3` varchar(250) NOT NULL,
  `CXM1` varchar(250) NOT NULL,
  `CXM2` varchar(250) NOT NULL,
  `CXM3` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bacteriology`
--
ALTER TABLE `bacteriology`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bacteriology`
--
ALTER TABLE `bacteriology`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
